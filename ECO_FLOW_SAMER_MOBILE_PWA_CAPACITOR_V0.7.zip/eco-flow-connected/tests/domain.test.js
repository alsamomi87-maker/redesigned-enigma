import test from 'node:test';
import assert from 'node:assert/strict';
import { canTransition, statusLabel } from '../src/domain.js';

test('privileged financial roles can request only supported journal transitions', () => {
  assert.equal(canTransition(['owner'], 'post'), true);
  assert.equal(canTransition(['finance_manager'], 'approve'), true);
  assert.equal(canTransition(['member'], 'post'), false);
  assert.equal(canTransition(['owner'], 'delete'), false);
});

test('status labels are localized and unknown states remain visible', () => {
  assert.equal(statusLabel('posted'), 'مرحّل');
  assert.equal(statusLabel('draft'), 'مسودة');
  assert.equal(statusLabel('custom_state'), 'custom_state');
});

test('PMO states and priorities are localized', () => {
  assert.equal(statusLabel('backlog'), 'قائمة الانتظار');
  assert.equal(statusLabel('done'), 'مكتملة');
  assert.equal(statusLabel('critical'), 'حرجة');
});
