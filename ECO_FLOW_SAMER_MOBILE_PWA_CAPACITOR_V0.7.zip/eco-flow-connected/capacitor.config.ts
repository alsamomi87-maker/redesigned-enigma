import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'sa.ecoflowsamer.erp',
  appName: 'ECO FLOW SAMER',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' },
  ios: { contentInset: 'automatic' }
};

export default config;
