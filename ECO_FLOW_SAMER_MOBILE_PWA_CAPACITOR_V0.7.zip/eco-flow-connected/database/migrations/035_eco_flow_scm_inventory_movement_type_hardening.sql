-- Permit controlled transfer movements and revoke direct execution of the posting trigger.
alter table scm.inventory_movements drop constraint if exists inventory_movements_source_type_check;
alter table scm.inventory_movements add constraint inventory_movements_source_type_check check(source_type in ('goods_receipt','adjustment','issue','transfer'));
-- Keep the trigger function definition aligned with the approved movement source types.
create or replace function scm.post_inventory_operation() returns trigger language plpgsql security definer set search_path=pg_catalog,scm set row_security=off as $$
declare l record;v_balance numeric;
begin
 if new.status='approved' and old.status is distinct from new.status then
  for l in select * from scm.inventory_operation_lines where operation_id=new.id and tenant_id=new.tenant_id order by line_no loop
   if new.operation_type='issue' then
    insert into scm.inventory_movements(tenant_id,warehouse_id,item_id,source_type,source_id,quantity_delta,movement_note,created_by) values(new.tenant_id,l.source_warehouse_id,l.item_id,'issue',new.id,-l.quantity,coalesce(l.notes,new.title),new.created_by);
   elsif new.operation_type='transfer' then
    insert into scm.inventory_movements(tenant_id,warehouse_id,item_id,source_type,source_id,quantity_delta,movement_note,created_by) values(new.tenant_id,l.source_warehouse_id,l.item_id,'transfer',new.id,-l.quantity,coalesce(l.notes,new.title),new.created_by),(new.tenant_id,l.destination_warehouse_id,l.item_id,'transfer',new.id,l.quantity,coalesce(l.notes,new.title),new.created_by);
   elsif new.operation_type='stocktake' then
    select quantity_on_hand into v_balance from scm.inventory_balances where tenant_id=new.tenant_id and warehouse_id=l.source_warehouse_id and item_id=l.item_id for update;
    v_balance:=coalesce(v_balance,0);
    if l.counted_quantity-v_balance<>0 then insert into scm.inventory_movements(tenant_id,warehouse_id,item_id,source_type,source_id,quantity_delta,movement_note,created_by) values(new.tenant_id,l.source_warehouse_id,l.item_id,'adjustment',new.id,l.counted_quantity-v_balance,coalesce(l.notes,new.title),new.created_by); end if;
   end if;
  end loop;
  update scm.inventory_operations set status='posted',posted_at=now() where id=new.id and tenant_id=new.tenant_id;
 end if;
 return new;
end $$;
revoke all on function scm.post_inventory_operation() from public,anon,authenticated;
