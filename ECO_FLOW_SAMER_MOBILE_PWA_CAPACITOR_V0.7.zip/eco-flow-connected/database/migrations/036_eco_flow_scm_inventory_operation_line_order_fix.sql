-- Correct argument-to-column ordering for inventory operation lines.
create or replace function scm.add_inventory_operation_line(p_operation_id uuid,p_line_no integer,p_item_id uuid,p_source_warehouse_id uuid,p_quantity numeric,p_destination_warehouse_id uuid default null,p_counted_quantity numeric default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=pg_catalog,scm,core set row_security=off as $$
declare v_op scm.inventory_operations%rowtype;v_id uuid;
begin
 select * into v_op from scm.inventory_operations where id=p_operation_id and tenant_id in(select tenant_id from core.tenant_memberships where user_id=auth.uid() and status='active') for update;
 if not found or not core.has_tenant_role(v_op.tenant_id,array['owner','admin']) then raise exception 'Operation not found or not authorized'; end if;
 if v_op.status<>'draft' then raise exception 'Only draft operations can be edited'; end if;
 if p_quantity is null or p_quantity<=0 then raise exception 'Quantity must be positive'; end if;
 if not exists(select 1 from scm.inventory_items i where i.id=p_item_id and i.tenant_id=v_op.tenant_id and i.item_type='stock' and i.is_active) then raise exception 'Active stock item required'; end if;
 if not exists(select 1 from scm.warehouses w where w.id=p_source_warehouse_id and w.tenant_id=v_op.tenant_id and w.is_active) then raise exception 'Active source warehouse required'; end if;
 if v_op.operation_type='transfer' then
  if p_destination_warehouse_id is null or p_destination_warehouse_id=p_source_warehouse_id or not exists(select 1 from scm.warehouses w where w.id=p_destination_warehouse_id and w.tenant_id=v_op.tenant_id and w.is_active) then raise exception 'A different active destination warehouse is required'; end if;
 elsif p_destination_warehouse_id is not null then raise exception 'Destination warehouse only applies to transfers'; end if;
 if v_op.operation_type='stocktake' then
  if p_counted_quantity is null or p_counted_quantity<0 then raise exception 'Counted quantity is required for stocktake'; end if;
 elsif p_counted_quantity is not null then raise exception 'Counted quantity only applies to stocktake'; end if;
 insert into scm.inventory_operation_lines(tenant_id,operation_id,line_no,item_id,source_warehouse_id,destination_warehouse_id,quantity,counted_quantity,notes)
 values(v_op.tenant_id,v_op.id,p_line_no,p_item_id,p_source_warehouse_id,p_destination_warehouse_id,p_quantity,p_counted_quantity,nullif(p_notes,'')) returning id into v_id;
 return v_id;
end $$;
revoke all on function scm.add_inventory_operation_line(uuid,integer,uuid,uuid,numeric,uuid,numeric,text) from public,anon;
grant execute on function scm.add_inventory_operation_line(uuid,integer,uuid,uuid,numeric,uuid,numeric,text) to authenticated;
