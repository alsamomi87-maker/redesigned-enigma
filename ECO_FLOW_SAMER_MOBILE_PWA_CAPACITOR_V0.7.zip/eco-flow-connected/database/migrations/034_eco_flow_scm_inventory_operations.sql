-- SCM inventory issue, transfer and stocktake documents; approval-gated posting.
create table if not exists scm.inventory_operations (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references core.tenants(id),
 operation_no text not null, operation_type text not null check (operation_type in ('issue','transfer','stocktake')),
 title text not null, notes text, project_id uuid, cost_center_id uuid,
 status text not null default 'draft' check (status in ('draft','submitted','approved','rejected','posted')),
 approval_request_id uuid, created_by uuid not null references auth.users(id), created_at timestamptz not null default now(),
 submitted_at timestamptz, posted_at timestamptz, unique(tenant_id,id), unique(tenant_id,operation_no),
 foreign key(project_id,tenant_id) references pmo.projects(id,tenant_id),
 foreign key(cost_center_id,tenant_id) references core.org_units(id,tenant_id),
 foreign key(approval_request_id,tenant_id) references workflow.approval_requests(id,tenant_id)
);
create table if not exists scm.inventory_operation_lines (
 id uuid primary key default gen_random_uuid(), tenant_id uuid not null references core.tenants(id),
 operation_id uuid not null, line_no integer not null check(line_no>0), item_id uuid not null,
 source_warehouse_id uuid not null, destination_warehouse_id uuid, quantity numeric(18,3) not null check(quantity>0),
 counted_quantity numeric(18,3) check(counted_quantity is null or counted_quantity>=0), notes text,
 created_at timestamptz not null default now(), unique(tenant_id,id), unique(operation_id,line_no),
 unique(operation_id,item_id,source_warehouse_id),
 foreign key(operation_id,tenant_id) references scm.inventory_operations(id,tenant_id),
 foreign key(item_id,tenant_id) references scm.inventory_items(id,tenant_id),
 foreign key(source_warehouse_id,tenant_id) references scm.warehouses(id,tenant_id),
 foreign key(destination_warehouse_id,tenant_id) references scm.warehouses(id,tenant_id),
 check(destination_warehouse_id is null or destination_warehouse_id<>source_warehouse_id)
);
create index if not exists inventory_operations_tenant_status_idx on scm.inventory_operations(tenant_id,status,created_at desc);
create index if not exists inventory_operation_lines_operation_idx on scm.inventory_operation_lines(tenant_id,operation_id);
alter table scm.inventory_operations enable row level security;
alter table scm.inventory_operation_lines enable row level security;
drop policy if exists scm_inventory_operations_read on scm.inventory_operations;
create policy scm_inventory_operations_read on scm.inventory_operations for select to authenticated using(core.is_tenant_member(tenant_id));
drop policy if exists scm_inventory_operation_lines_read on scm.inventory_operation_lines;
create policy scm_inventory_operation_lines_read on scm.inventory_operation_lines for select to authenticated using(core.is_tenant_member(tenant_id));
revoke insert,update,delete on scm.inventory_operations from anon,authenticated;
revoke insert,update,delete on scm.inventory_operation_lines from anon,authenticated;
grant select on scm.inventory_operations,scm.inventory_operation_lines to authenticated;

create or replace function scm.create_inventory_operation(p_operation_no text,p_operation_type text,p_title text,p_notes text default null,p_project_id uuid default null,p_cost_center_id uuid default null)
returns uuid language plpgsql security definer set search_path=pg_catalog,scm,core set row_security=off as $$
declare v_tenant uuid;v_id uuid;
begin
 select tenant_id into v_tenant from core.tenant_memberships where user_id=auth.uid() and status='active' order by joined_at limit 1;
 if v_tenant is null or not core.has_tenant_role(v_tenant,array['owner','admin']) then raise exception 'Not authorized'; end if;
 if p_operation_type not in ('issue','transfer','stocktake') then raise exception 'Invalid inventory operation type'; end if;
 insert into scm.inventory_operations(tenant_id,operation_no,operation_type,title,notes,project_id,cost_center_id,created_by)
 values(v_tenant,btrim(p_operation_no),p_operation_type,btrim(p_title),nullif(p_notes,''),p_project_id,p_cost_center_id,auth.uid()) returning id into v_id;
 return v_id;
end $$;

create or replace function scm.add_inventory_operation_line(p_operation_id uuid,p_line_no integer,p_item_id uuid,p_source_warehouse_id uuid,p_quantity numeric,p_destination_warehouse_id uuid default null,p_counted_quantity numeric default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=pg_catalog,scm,core set row_security=off as $$
declare v_op scm.inventory_operations%rowtype;v_id uuid;
begin
 select * into v_op from scm.inventory_operations where id=p_operation_id and tenant_id in(select tenant_id from core.tenant_memberships where user_id=auth.uid() and status='active') for update;
 if not found or not core.has_tenant_role(v_op.tenant_id,array['owner','admin']) then raise exception 'Operation not found or not authorized'; end if;
 if v_op.status<>'draft' then raise exception 'Only draft operations can be edited'; end if;
 if p_quantity is null or p_quantity<=0 then raise exception 'Quantity must be positive'; end if;
 if not exists(select 1 from scm.inventory_items i where i.id=p_item_id and i.tenant_id=v_op.tenant_id and i.item_type='stock' and i.is_active) then raise exception 'Active stock item required'; end if;
 if not exists(select 1 from scm.warehouses w where w.id=p_source_warehouse_id and w.tenant_id=v_op.tenant_id and w.is_active) then raise exception 'Active source warehouse required'; end if;
 if v_op.operation_type='transfer' then
  if p_destination_warehouse_id is null or p_destination_warehouse_id=p_source_warehouse_id or not exists(select 1 from scm.warehouses w where w.id=p_destination_warehouse_id and w.tenant_id=v_op.tenant_id and w.is_active) then raise exception 'A different active destination warehouse is required'; end if;
 elsif p_destination_warehouse_id is not null then raise exception 'Destination warehouse only applies to transfers'; end if;
 if v_op.operation_type='stocktake' then
  if p_counted_quantity is null or p_counted_quantity<0 then raise exception 'Counted quantity is required for stocktake'; end if;
 elsif p_counted_quantity is not null then raise exception 'Counted quantity only applies to stocktake'; end if;
 insert into scm.inventory_operation_lines(tenant_id,operation_id,line_no,item_id,source_warehouse_id,destination_warehouse_id,quantity,counted_quantity,notes)
 values(v_op.tenant_id,v_op.id,p_line_no,p_item_id,p_source_warehouse_id,p_destination_warehouse_id,p_quantity,p_counted_quantity,nullif(p_notes,'')) returning id into v_id;
 return v_id;
end $$;

create or replace function scm.post_inventory_operation() returns trigger language plpgsql security definer set search_path=pg_catalog,scm set row_security=off as $$
declare l record;v_balance numeric;
begin
 if new.status='approved' and old.status is distinct from new.status then
  for l in select * from scm.inventory_operation_lines where operation_id=new.id and tenant_id=new.tenant_id order by line_no loop
   if new.operation_type='issue' then
    insert into scm.inventory_movements(tenant_id,warehouse_id,item_id,source_type,source_id,quantity_delta,movement_note,created_by) values(new.tenant_id,l.source_warehouse_id,l.item_id,'issue',new.id,-l.quantity,coalesce(l.notes,new.title),new.created_by);
   elsif new.operation_type='transfer' then
    insert into scm.inventory_movements(tenant_id,warehouse_id,item_id,source_type,source_id,quantity_delta,movement_note,created_by)
    values(new.tenant_id,l.source_warehouse_id,l.item_id,'transfer',new.id,-l.quantity,coalesce(l.notes,new.title),new.created_by),(new.tenant_id,l.destination_warehouse_id,l.item_id,'transfer',new.id,l.quantity,coalesce(l.notes,new.title),new.created_by);
   elsif new.operation_type='stocktake' then
    select quantity_on_hand into v_balance from scm.inventory_balances where tenant_id=new.tenant_id and warehouse_id=l.source_warehouse_id and item_id=l.item_id for update;
    v_balance:=coalesce(v_balance,0);
    if l.counted_quantity-v_balance<>0 then
     insert into scm.inventory_movements(tenant_id,warehouse_id,item_id,source_type,source_id,quantity_delta,movement_note,created_by) values(new.tenant_id,l.source_warehouse_id,l.item_id,'adjustment',new.id,l.counted_quantity-v_balance,coalesce(l.notes,new.title),new.created_by);
    end if;
   end if;
  end loop;
  update scm.inventory_operations set status='posted',posted_at=now() where id=new.id and tenant_id=new.tenant_id;
 end if;
 return new;
end $$;
drop trigger if exists scm_post_inventory_operation on scm.inventory_operations;
create trigger scm_post_inventory_operation after update of status on scm.inventory_operations for each row execute function scm.post_inventory_operation();

create or replace function scm.submit_inventory_operation(p_operation_id uuid) returns uuid language plpgsql security definer set search_path=pg_catalog,scm,workflow,core set row_security=off as $$
declare v_op scm.inventory_operations%rowtype;v_approval uuid;
begin
 select * into v_op from scm.inventory_operations where id=p_operation_id and tenant_id in(select tenant_id from core.tenant_memberships where user_id=auth.uid() and status='active') for update;
 if not found or not core.has_tenant_role(v_op.tenant_id,array['owner','admin']) then raise exception 'Operation not found or not authorized'; end if;
 if v_op.status<>'draft' then raise exception 'Only draft operations can be submitted'; end if;
 if not exists(select 1 from scm.inventory_operation_lines where operation_id=v_op.id and tenant_id=v_op.tenant_id) then raise exception 'Operation requires at least one line'; end if;
 if v_op.operation_type in ('issue','transfer') and exists(
  select 1 from scm.inventory_operation_lines l left join scm.inventory_balances b on b.tenant_id=l.tenant_id and b.warehouse_id=l.source_warehouse_id and b.item_id=l.item_id
  where l.operation_id=v_op.id and l.tenant_id=v_op.tenant_id group by l.id,l.quantity,b.quantity_on_hand having coalesce(b.quantity_on_hand,0)<l.quantity
 ) then raise exception 'Insufficient stock for one or more lines'; end if;
 insert into workflow.approval_requests(tenant_id,requester_user_id,request_type,subject,payload,status)
 values(v_op.tenant_id,auth.uid(),'inventory_operation','اعتماد حركة مخزون: '||v_op.title,jsonb_build_object('operation_id',v_op.id,'operation_no',v_op.operation_no,'operation_type',v_op.operation_type),'pending') returning id into v_approval;
 update scm.inventory_operations set status='submitted',approval_request_id=v_approval,submitted_at=now() where id=v_op.id and tenant_id=v_op.tenant_id;
 return v_approval;
end $$;

create or replace function scm.sync_procurement_approval() returns trigger language plpgsql security definer set search_path=pg_catalog,scm,workflow set row_security=off as $$
begin
 if new.status=old.status then return new; end if;
 if new.request_type='purchase_request' and new.status in ('approved','rejected') then
  update scm.purchase_requests set status=case when new.status='approved' then 'approved' else 'rejected' end,approved_at=case when new.status='approved' then coalesce(new.decided_at,now()) else null end,updated_at=now() where approval_request_id=new.id and tenant_id=new.tenant_id and status='submitted';
 elsif new.request_type='supplier_approval' and new.status in ('approved','rejected') then
  update scm.suppliers set approval_status=case when new.status='approved' then 'approved' else 'rejected' end,updated_at=now() where approval_request_id=new.id and tenant_id=new.tenant_id and approval_status='pending';
 elsif new.request_type='purchase_order' and new.status in ('approved','rejected') then
  update scm.purchase_orders set status=case when new.status='approved' then 'approved' else 'draft' end,updated_at=now() where approval_request_id=new.id and tenant_id=new.tenant_id and status='submitted';
 elsif new.request_type='inventory_operation' and new.status in ('approved','rejected') then
  update scm.inventory_operations set status=case when new.status='approved' then 'approved' else 'rejected' end where approval_request_id=new.id and tenant_id=new.tenant_id and status='submitted';
 end if;
 return new;
end $$;
revoke all on function scm.create_inventory_operation(text,text,text,text,uuid,uuid) from public,anon;
revoke all on function scm.add_inventory_operation_line(uuid,integer,uuid,uuid,numeric,uuid,numeric,text) from public,anon;
revoke all on function scm.submit_inventory_operation(uuid) from public,anon;
grant execute on function scm.create_inventory_operation(text,text,text,text,uuid,uuid) to authenticated;
grant execute on function scm.add_inventory_operation_line(uuid,integer,uuid,uuid,numeric,uuid,numeric,text) to authenticated;
grant execute on function scm.submit_inventory_operation(uuid) to authenticated;
