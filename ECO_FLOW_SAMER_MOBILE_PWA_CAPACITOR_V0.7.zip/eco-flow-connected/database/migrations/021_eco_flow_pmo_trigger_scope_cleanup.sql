drop trigger if exists tasks_validate_tenant_links on pmo.tasks;
drop trigger if exists project_members_validate_tenant_links on pmo.project_members;
