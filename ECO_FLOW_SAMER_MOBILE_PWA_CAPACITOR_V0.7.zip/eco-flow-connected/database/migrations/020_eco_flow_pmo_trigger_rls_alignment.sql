create or replace function pmo.validate_tenant_links()
returns trigger
language plpgsql
set search_path = pg_catalog, pmo, core
as $function$
begin
  if tg_table_name = 'projects' then
    if new.org_unit_id is not null and exists (
      select 1 from core.org_units u
      where u.id = new.org_unit_id and u.tenant_id = new.tenant_id and u.unit_type = 'cost_center'
    ) then
      raise exception 'Project organizational unit cannot be a cost center';
    end if;
    if new.cost_center_id is not null and not exists (
      select 1 from core.org_units u
      where u.id = new.cost_center_id and u.tenant_id = new.tenant_id and u.unit_type = 'cost_center'
    ) then
      raise exception 'Project cost_center_id must reference a cost center in the same tenant';
    end if;
  end if;
  return new;
end;
$function$;
