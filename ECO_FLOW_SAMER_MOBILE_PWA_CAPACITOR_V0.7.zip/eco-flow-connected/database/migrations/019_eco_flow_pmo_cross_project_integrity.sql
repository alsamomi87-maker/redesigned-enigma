alter table pmo.milestones add constraint milestones_id_project_id_tenant_id_key unique (id, project_id, tenant_id);
alter table pmo.tasks drop constraint tasks_milestone_id_tenant_id_fkey;
alter table pmo.tasks add constraint tasks_milestone_id_project_id_tenant_id_fkey
  foreign key (milestone_id, project_id, tenant_id)
  references pmo.milestones(id, project_id, tenant_id)
  on delete set null (milestone_id);
create index tasks_milestone_project_tenant_fk_idx
  on pmo.tasks(milestone_id, project_id, tenant_id)
  where milestone_id is not null;

create or replace function pmo.validate_tenant_links()
returns trigger
language plpgsql
set search_path = pg_catalog, pmo, core
as $function$
begin
  if tg_table_name = 'projects' then
    if new.org_unit_id is not null and exists (
      select 1 from core.org_units u
      where u.id = new.org_unit_id and u.tenant_id = new.tenant_id and u.unit_type = 'cost_center'
    ) then
      raise exception 'Project organizational unit cannot be a cost center';
    end if;
    if new.cost_center_id is not null and not exists (
      select 1 from core.org_units u
      where u.id = new.cost_center_id and u.tenant_id = new.tenant_id and u.unit_type = 'cost_center'
    ) then
      raise exception 'Project cost_center_id must reference a cost center in the same tenant';
    end if;
    if new.owner_membership_id is not null and not exists (
      select 1 from core.tenant_memberships m
      where m.id = new.owner_membership_id and m.tenant_id = new.tenant_id and m.status = 'active'
    ) then
      raise exception 'Project owner must be an active tenant member';
    end if;
  elsif tg_table_name = 'tasks' then
    if new.assigned_membership_id is not null and not exists (
      select 1 from core.tenant_memberships m
      where m.id = new.assigned_membership_id and m.tenant_id = new.tenant_id and m.status = 'active'
    ) then
      raise exception 'Task assignee must be an active tenant member';
    end if;
  elsif tg_table_name = 'project_members' then
    if not exists (
      select 1 from core.tenant_memberships m
      where m.id = new.membership_id and m.tenant_id = new.tenant_id and m.status = 'active'
    ) then
      raise exception 'Project member must be an active tenant member';
    end if;
  end if;
  return new;
end;
$function$;

create trigger projects_validate_tenant_links
before insert or update of tenant_id, org_unit_id, cost_center_id, owner_membership_id
on pmo.projects for each row execute function pmo.validate_tenant_links();
create trigger tasks_validate_tenant_links
before insert or update of tenant_id, assigned_membership_id
on pmo.tasks for each row execute function pmo.validate_tenant_links();
create trigger project_members_validate_tenant_links
before insert or update of tenant_id, membership_id
on pmo.project_members for each row execute function pmo.validate_tenant_links();
grant execute on function pmo.validate_tenant_links() to authenticated;
