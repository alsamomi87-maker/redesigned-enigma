alter table pmo.tasks drop constraint tasks_milestone_id_tenant_id_fkey;
alter table pmo.tasks add constraint tasks_milestone_id_tenant_id_fkey
  foreign key (milestone_id, tenant_id) references pmo.milestones(id, tenant_id)
  on delete set null (milestone_id);
alter table pmo.tasks drop constraint tasks_parent_task_id_project_id_tenant_id_fkey;
alter table pmo.tasks add constraint tasks_parent_task_id_project_id_tenant_id_fkey
  foreign key (parent_task_id, project_id, tenant_id) references pmo.tasks(id, project_id, tenant_id)
  on delete set null (parent_task_id);
alter table pmo.tasks drop constraint tasks_assigned_membership_id_tenant_id_fkey;
alter table pmo.tasks add constraint tasks_assigned_membership_id_tenant_id_fkey
  foreign key (assigned_membership_id, tenant_id) references core.tenant_memberships(id, tenant_id)
  on delete set null (assigned_membership_id);
