create schema if not exists pmo;
grant usage on schema pmo to authenticated;

create table pmo.projects (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references core.tenants(id) on delete cascade,
  project_code text not null check (length(btrim(project_code)) > 0), name text not null check (length(btrim(name)) > 0),
  description text, org_unit_id uuid, cost_center_id uuid, owner_membership_id uuid,
  sponsor_user_id uuid references auth.users(id) on delete set null,
  status text not null default 'planned' check (status in ('planned','active','on_hold','completed','cancelled')),
  priority text not null default 'normal' check (priority in ('low','normal','high','critical')),
  progress_pct numeric(5,2) not null default 0 check (progress_pct between 0 and 100),
  planned_start date, planned_end date, actual_start date, actual_end date,
  approved_budget numeric(14,2) check (approved_budget is null or approved_budget >= 0),
  currency_code char(3) not null default 'SAR', created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (tenant_id, id), unique (tenant_id, project_code),
  foreign key (org_unit_id, tenant_id) references core.org_units(id, tenant_id),
  foreign key (cost_center_id, tenant_id) references core.org_units(id, tenant_id),
  foreign key (owner_membership_id, tenant_id) references core.tenant_memberships(id, tenant_id),
  check (planned_end is null or planned_start is null or planned_end >= planned_start),
  check (actual_end is null or actual_start is null or actual_end >= actual_start)
);

create table pmo.project_members (
  tenant_id uuid not null references core.tenants(id) on delete cascade, project_id uuid not null, membership_id uuid not null,
  project_role text not null default 'member' check (project_role in ('lead','member','viewer')),
  added_by uuid not null references auth.users(id), added_at timestamptz not null default now(),
  primary key (project_id, membership_id),
  foreign key (project_id, tenant_id) references pmo.projects(id, tenant_id) on delete cascade,
  foreign key (membership_id, tenant_id) references core.tenant_memberships(id, tenant_id) on delete restrict
);

create table pmo.milestones (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references core.tenants(id) on delete cascade,
  project_id uuid not null, milestone_code text not null check (length(btrim(milestone_code)) > 0),
  name text not null check (length(btrim(name)) > 0), description text, due_date date, completed_at timestamptz,
  status text not null default 'pending' check (status in ('pending','in_progress','completed','delayed','cancelled')),
  sort_order integer not null default 0, created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (tenant_id, id), unique (tenant_id, project_id, milestone_code),
  foreign key (project_id, tenant_id) references pmo.projects(id, tenant_id) on delete cascade
);

create table pmo.tasks (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references core.tenants(id) on delete cascade,
  project_id uuid not null, milestone_id uuid, parent_task_id uuid, task_code text not null check (length(btrim(task_code)) > 0),
  title text not null check (length(btrim(title)) > 0), description text, assigned_membership_id uuid,
  status text not null default 'backlog' check (status in ('backlog','todo','in_progress','blocked','done','cancelled')),
  priority text not null default 'normal' check (priority in ('low','normal','high','critical')),
  progress_pct numeric(5,2) not null default 0 check (progress_pct between 0 and 100),
  planned_start date, due_date date, completed_at timestamptz,
  estimated_hours numeric(10,2) check (estimated_hours is null or estimated_hours >= 0),
  actual_hours numeric(10,2) not null default 0 check (actual_hours >= 0),
  created_by uuid not null references auth.users(id), created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (tenant_id, id), unique (id, project_id, tenant_id), unique (tenant_id, project_id, task_code),
  foreign key (project_id, tenant_id) references pmo.projects(id, tenant_id) on delete cascade,
  foreign key (milestone_id, tenant_id) references pmo.milestones(id, tenant_id) on delete set null,
  foreign key (parent_task_id, project_id, tenant_id) references pmo.tasks(id, project_id, tenant_id) on delete set null,
  foreign key (assigned_membership_id, tenant_id) references core.tenant_memberships(id, tenant_id) on delete set null,
  check (due_date is null or planned_start is null or due_date >= planned_start)
);

create index projects_tenant_status_idx on pmo.projects(tenant_id, status, planned_start);
create index projects_org_unit_idx on pmo.projects(tenant_id, org_unit_id) where org_unit_id is not null;
create index project_members_tenant_membership_idx on pmo.project_members(tenant_id, membership_id);
create index milestones_project_due_idx on pmo.milestones(tenant_id, project_id, due_date);
create index tasks_project_status_due_idx on pmo.tasks(tenant_id, project_id, status, due_date);
create index tasks_assignee_status_idx on pmo.tasks(tenant_id, assigned_membership_id, status) where assigned_membership_id is not null;
create index tasks_parent_idx on pmo.tasks(tenant_id, parent_task_id) where parent_task_id is not null;

alter table pmo.projects enable row level security;
alter table pmo.project_members enable row level security;
alter table pmo.milestones enable row level security;
alter table pmo.tasks enable row level security;

create policy projects_read_tenant on pmo.projects for select to authenticated using (core.is_tenant_member(tenant_id));
create policy projects_insert_manager on pmo.projects for insert to authenticated with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy projects_update_manager on pmo.projects for update to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager'])) with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy projects_delete_admin on pmo.projects for delete to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin']));
create policy project_members_read_tenant on pmo.project_members for select to authenticated using (core.is_tenant_member(tenant_id));
create policy project_members_insert_manager on pmo.project_members for insert to authenticated with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy project_members_update_manager on pmo.project_members for update to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager'])) with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy project_members_delete_manager on pmo.project_members for delete to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy milestones_read_tenant on pmo.milestones for select to authenticated using (core.is_tenant_member(tenant_id));
create policy milestones_insert_manager on pmo.milestones for insert to authenticated with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy milestones_update_manager on pmo.milestones for update to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager'])) with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy milestones_delete_manager on pmo.milestones for delete to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy tasks_read_tenant on pmo.tasks for select to authenticated using (core.is_tenant_member(tenant_id));
create policy tasks_insert_manager on pmo.tasks for insert to authenticated with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy tasks_update_manager on pmo.tasks for update to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager'])) with check (core.has_tenant_role(tenant_id, array['owner','admin','manager']));
create policy tasks_delete_manager on pmo.tasks for delete to authenticated using (core.has_tenant_role(tenant_id, array['owner','admin','manager']));

grant select, insert, update, delete on pmo.projects, pmo.project_members, pmo.milestones, pmo.tasks to authenticated;
