# سجل ترحيلات المشتريات وسلسلة الإمداد — TEST

تم تسجيل الترحيلات التالية في قاعدة Supabase TEST للمشروع `zlqfsqogxdstwxhmsphx`:

1. `eco_flow_scm_procurement_foundation_022` — مخطط SCM والجداول الأساسية والمفاتيح المركبة وRLS والأدوار.
2. `eco_flow_scm_rls_and_fk_index_hardening_023` — فصل سياسات القراءة/الكتابة/الحذف وتغطية فهارس المفاتيح الأجنبية.
3. `eco_flow_scm_workflow_approval_link_024` — ربط اعتماد المورد وطلب الشراء بمحرك الموافقات.
4. `eco_flow_scm_atomic_workflows_025` — إنشاء طلب شراء وبنده كوحدة ذرية، وإصدار RFQ، وتسجيل الاستلام.
5. `eco_flow_scm_evaluation_po_commitments_026` — تقييم العروض، أمر الشراء ومسار اعتماده، وحجوزات الميزانية.
6. `eco_flow_scm_budget_control_and_receiving_027` — حجز مخصصات الميزانية والتحقق من الاستلام وأمر الشراء الصادر.
7. `eco_flow_scm_internal_trigger_privilege_hardening_028` — تقوية المشغلات الداخلية لمزامنة الموافقات وحجز الميزانية.

## الجداول
`scm.suppliers`, `scm.purchase_requests`, `scm.purchase_request_lines`, `scm.rfqs`, `scm.rfq_suppliers`, `scm.supplier_quotes`, `scm.supplier_quote_lines`, `scm.quote_evaluations`, `scm.purchase_orders`, `scm.purchase_order_lines`, `scm.goods_receipts`, `scm.goods_receipt_lines`, `scm.budget_commitments`.

## تنبيه مصدر
هذا الملف سجل ترحيلات وأوصاف تنفيذية، وليس بديلاً عن SQL الترحيلات الأصلي. المصدر المرجعي لتاريخ تطبيقها هو سجل `supabase_migrations.schema_migrations` في مشروع TEST. يجب تصدير SQL migrations من مستودع المشروع وإيداعها قبل اعتماد نسخة إصدار قابلة لإعادة النشر.

8. `eco_flow_scm_inventory_warehouse_foundation_029` — المستودعات وكتالوج الأصناف وحركات المخزون وأرصدته وربط الصنف ببنود الطلب والأمر والاستلام.
9. `eco_flow_scm_disable_legacy_receipt_path_030` — تعطيل مسار الاستلام القديم ذي المعاملات السبعة لتجنب تجاوز تحديث المخزون.
10. `eco_flow_scm_stock_item_receipt_guard_031` — قصر إنشاء حركة المخزون على الصنف المخزني المقبول والتحقق من المستودع النشط.

## مكونات المخزون المضافة
`scm.warehouses`, `scm.inventory_items`, `scm.inventory_movements`, `scm.inventory_balances`؛ والاستلام المخزني يحدّث الرصيد من خلال مشغل داخلي غير متاح للاستدعاء المباشر.

11. `eco_flow_scm_approval_step_engine_032` — إنشاء خطوة موافقة تلقائية وتوفير RPC لاتخاذ قرار المالك/المشرف.
12. `eco_flow_scm_rpc_state_transition_hardening_033` — تقييد صلاحيات تغييرات الحالة الحساسة وتوجيهها عبر RPCs محمية، وتعطيل DML المباشر على سجلات الاستلام وبنود أوامر الشراء.

13. `eco_flow_scm_inventory_operations_034` — إنشاء مستندات الصرف والتحويل والجرد وبنودها، مسارات RPC محمية، موافقة مؤسسية قبل الترحيل، وربط قرار الموافقة بحركة المخزون.
14. `eco_flow_scm_inventory_movement_type_hardening_035` — السماح بنوع حركة التحويل، قصر مصادر الحركات على الأنواع المحددة، وسحب EXECUTE العام عن دالة الترحيل الداخلية.
15. `eco_flow_scm_inventory_operation_line_order_fix_036` — تصحيح ترتيب معاملات إضافة بند عملية المخزون والتحقق من صلاحيات RPC.

تم حفظ SQL للترحيلات الجديدة 034–036 في `database/migrations/`. لا تزال ملفات SQL الأصلية للترحيلات SCM 022–033 غير مضمنة في هذه الحزمة؛ سجلها المرجعي في قاعدة TEST.
