export const fmtMoney = (value) => new Intl.NumberFormat('ar-SA', {
  style: 'currency', currency: 'SAR', maximumFractionDigits: 2
}).format(Number(value || 0));

export const fmtNumber = (value) => new Intl.NumberFormat('ar-SA').format(Number(value || 0));

export const statusLabel = (value) => ({
  draft: 'مسودة', submitted: 'مرسل للموافقة', pending: 'بانتظار الإجراء',
  under_review: 'قيد المراجعة', issued: 'صادر', awarded: 'تمت الترسية', reserved: 'محجوز', released: 'محرر', consumed: 'مستهلك', partially_received: 'مستلم جزئياً', received: 'مستلم', selected: 'مرسى', invited: 'مدعو', responded: 'تم الرد', declined: 'اعتذر', no_response: 'لم يرد', suspended: 'موقوف',
  approved: 'معتمد', posted: 'مرحّل', rejected: 'مرفوض', cancelled: 'ملغي',
  calculated: 'محتسب', active: 'نشط', inactive: 'غير نشط', closed: 'مغلق',
  open: 'مفتوح', planned: 'مخطط', in_progress: 'قيد التنفيذ',
  suspended: 'موقوف', archived: 'مؤرشف', paid: 'مدفوع', part_paid: 'مدفوع جزئياً',
  backlog: 'قائمة الانتظار', todo: 'مجدولة', blocked: 'متوقفة', done: 'مكتملة',
  completed: 'مكتمل', on_hold: 'معلّق', delayed: 'متأخرة',
  low: 'منخفضة', normal: 'عادية', high: 'عالية', critical: 'حرجة'
}[value] || value || '—');

export const canTransition = (roles, action) => {
  const privileged = ['owner', 'admin', 'finance_manager'];
  return privileged.some((role) => roles.includes(role)) &&
    ['submit', 'approve', 'post', 'cancel'].includes(action);
};

export const cleanError = (error) => {
  if (!error) return 'حدث خطأ غير معروف';
  if (error.code === '42501' || error.status === 401 || error.status === 403) {
    return 'ليست لديك صلاحية لهذه العملية، أو أن سياسة الوصول من قاعدة البيانات منعتها.';
  }
  if (String(error.message || '').includes('schema cache')) {
    return 'المخطط المطلوب غير مكشوف عبر Data API. راجع قائمة Exposed schemas في إعدادات Supabase.';
  }
  return error.message || 'تعذر إكمال العملية';
};
