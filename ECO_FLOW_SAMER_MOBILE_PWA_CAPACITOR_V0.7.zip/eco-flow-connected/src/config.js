// Public browser configuration only. Never place service_role or secret keys here.
// Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY in the deployment environment.
export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://zlqfsqogxdstwxhmsphx.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'PASTE_SUPABASE_PUBLISHABLE_KEY_HERE';
