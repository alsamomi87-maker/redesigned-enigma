import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './config.js';
import { fmtMoney, fmtNumber, statusLabel, canTransition, cleanError } from './domain.js';
import './style.css';

// Cache only the static application shell; authenticated API/data are never cached.
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}

const app = document.querySelector('#app');
let deferredInstallPrompt = null;
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault(); deferredInstallPrompt = event; showInstallControl();
});
window.addEventListener('appinstalled', () => { deferredInstallPrompt = null; document.querySelector('#pwa-install-control')?.remove(); });
function showInstallControl() {
  if (document.querySelector('#pwa-install-control')) return;
  const button = document.createElement('button'); button.id = 'pwa-install-control';
  button.type = 'button'; button.textContent = 'تثبيت التطبيق';
  button.setAttribute('aria-label', 'تثبيت ECO FLOW SAMER على الجهاز');
  button.style.cssText = 'position:fixed;z-index:9999;bottom:18px;left:18px;padding:12px 18px;border:0;border-radius:12px;background:#10243a;color:#fff;font:600 14px inherit;box-shadow:0 6px 24px #10243a33;cursor:pointer';
  button.addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt(); await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null; button.remove();
  });
  document.body.append(button);
}

const configured = SUPABASE_URL.startsWith('https://') && SUPABASE_PUBLISHABLE_KEY && !SUPABASE_PUBLISHABLE_KEY.includes('PASTE_');
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
}) : null;

const state = { user: null, tenant: null, membership: null, roles: [], profile: null, page: 'dashboard', cache: {}, busy: false };
const nav = [
  ['dashboard','لوحة القيادة','▦'], ['organization','الهيكل المؤسسي','⌘'],
  ['pmo','المشاريع ومكتب PMO','▣'], ['scm','الموردون والمشتريات','⇄'], ['approvals','الموافقات','✓'], ['assets','الأصول الثابتة','▣'],
  ['depreciation','الإهلاك','◷'], ['ledger','دفتر الأستاذ','▤'],
  ['hr','الوظائف والموارد البشرية','♙'],
  ['finance','الميزانيات ودليل الحسابات','ر.'], ['assetops','تشغيل الأصول والجرد','⚙'],
  ['governance','الحوكمة وسجل التدقيق','◉'], ['expansion','مركز التوسع التشغيلي','＋']
];

function esc(v='') { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function toast(message, kind='info') {
  const el = document.querySelector('#toast'); if (!el) return;
  el.textContent = message; el.dataset.kind = kind; el.classList.add('show');
  window.clearTimeout(toast.timer); toast.timer = window.setTimeout(() => el.classList.remove('show'), 4200);
}
function statusPill(value) {
  const cls = ['approved','posted','active','open','completed','done'].includes(value) ? 'ok' : ['rejected','cancelled','suspended','blocked'].includes(value) ? 'bad' : 'wait';
  return `<span class="pill ${cls}">${esc(statusLabel(value))}</span>`;
}
function setupScreen() {
  app.innerHTML = `<main class="setup"><div class="brandmark">EF</div><p class="eyebrow">ECO FLOW SAMER · ERP</p><h1>إعداد الاتصال بقاعدة الاختبار</h1><p>ملفات الواجهة اعتمدت كبداية تنفيذية. أدخل مفتاح <b>Publishable</b> العام الخاص بمشروع الاختبار في <code>src/config.js</code> ثم أعد تشغيل التطبيق.</p><div class="notice">رابط المشروع مضبوط مسبقاً. لا تستخدم مفتاح <code>service_role</code> أو أي مفتاح سري داخل الواجهة.</div><p class="muted">المشروع الحالي: <b>Supabase TEST</b> — لا يحتوي هذا الإصدار على بيانات تشغيلية فعلية.</p><code>npm install && npm run dev</code></main>`;
}
function loginScreen(message='') {
  app.innerHTML = `<main class="login-wrap"><section class="login-card"><div class="brandmark">EF</div><div class="eyebrow">ECO FLOW SAMER</div><h1>منصة الإدارة المؤسسية</h1><p class="muted">سجّل الدخول بحسابك المعتمد للوصول إلى مساحة العمل.</p>${message ? `<div class="notice error">${esc(message)}</div>` : ''}<form id="login-form"><label>البريد الإلكتروني<input name="email" type="email" autocomplete="username" required placeholder="name@company.com"></label><label>كلمة المرور<input name="password" type="password" autocomplete="current-password" required placeholder="••••••••"></label><button class="primary full" type="submit">تسجيل الدخول</button></form><small>الوصول محكوم بصلاحيات المستخدم وسياسات RLS في قاعدة البيانات.</small></section></main>`;
  document.querySelector('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault(); const fd = new FormData(e.currentTarget); const btn = e.currentTarget.querySelector('button'); btn.disabled = true; btn.textContent = 'جارٍ التحقق…';
    const { error } = await supabase.auth.signInWithPassword({ email: fd.get('email'), password: fd.get('password') });
    if (error) { loginScreen(cleanError(error)); return; }
    await bootstrap();
  });
}

async function bootstrap() {
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) { loginScreen(); return; }
  state.user = user;
  const { data: memberships, error: mErr } = await supabase.schema('core').from('tenant_memberships')
    .select('id,tenant_id,status,joined_at').eq('user_id', user.id).eq('status','active');
  if (mErr) { loginScreen(cleanError(mErr)); return; }
  if (!memberships?.length) { loginScreen('لا توجد عضوية نشطة مرتبطة بهذا الحساب.'); return; }
  const membership = memberships[0]; state.membership = membership;
  const [{ data: tenant, error: tErr }, { data: profile }, { data: roleRows }] = await Promise.all([
    supabase.schema('core').from('tenants').select('id,display_name,legal_name,status,timezone').eq('id', membership.tenant_id).single(),
    supabase.schema('core').from('user_profiles').select('display_name,preferred_locale').eq('user_id', user.id).maybeSingle(),
    supabase.schema('core').from('membership_roles').select('role_key').eq('membership_id', membership.id)
  ]);
  if (tErr) { loginScreen(cleanError(tErr)); return; }
  state.tenant = tenant; state.profile = profile; state.roles = (roleRows || []).map(r => r.role_key);
  renderShell(); await loadPage('dashboard');
}

function renderShell() {
  const display = state.profile?.display_name || state.user.email;
  app.innerHTML = `<div class="shell"><aside class="sidebar" id="sidebar"><div class="brand"><div class="brandmark">EF</div><div><b>ECO FLOW</b><small>SAMER · ERP PLATFORM</small></div></div><div class="tenant"><span class="live-dot"></span><div><b>${esc(state.tenant.display_name)}</b><small>${esc(state.tenant.legal_name || 'كيان المؤسسة')}</small></div></div><div class="nav-title">مساحة العمل</div><nav>${nav.map(([id,label,icon])=>`<button class="nav-item ${id===state.page?'active':''}" data-page="${id}"><span>${icon}</span>${label}</button>`).join('')}</nav><div class="side-foot"><span class="env-tag">بيئة اختبار TEST</span><div class="user-chip"><div class="avatar">${esc((display||'EF').slice(0,1).toUpperCase())}</div><div><b>${esc(display)}</b><small>${esc(state.roles.join(' · ') || 'عضو')}</small></div></div><button class="ghost full" id="signout">تسجيل الخروج</button></div></aside><main class="main"><header class="topbar"><button class="mobile-menu" id="mobile-menu">☰</button><div><small>مؤسسة سامر السمومي</small><h2 id="page-heading">لوحة القيادة</h2></div><div class="top-actions"><span class="env-tag">TEST</span><button class="icon-button" id="refresh" title="تحديث البيانات">↻</button></div></header><section class="content" id="content"><div class="loading">جارٍ تحميل مساحة العمل…</div></section></main></div><div id="toast" class="toast"></div>`;
  document.querySelectorAll('[data-page]').forEach(b => b.addEventListener('click', () => loadPage(b.dataset.page)));
  document.querySelector('#signout').onclick = async () => { await supabase.auth.signOut(); state.user=null; loginScreen(); };
  document.querySelector('#refresh').onclick = () => loadPage(state.page);
  document.querySelector('#mobile-menu').onclick = () => document.querySelector('#sidebar').classList.toggle('open');
}

async function queryRows(schema, table, tenantScoped=true, limit=100) {
  let q = supabase.schema(schema).from(table).select('*').limit(limit);
  if (tenantScoped && state.tenant?.id) q = q.eq('tenant_id', state.tenant.id);
  const { data, error } = await q;
  if (error) throw error;
  return data || [];
}
async function queryPublic(view, limit=100) {
  const { data, error } = await supabase.from(view).select('*').eq('tenant_id', state.tenant.id).limit(limit);
  if (error) throw error; return data || [];
}
function pageTitle(id) { return nav.find(n=>n[0]===id)?.[1] || 'مساحة العمل'; }
async function loadPage(page) {
  state.page = page;
  document.querySelectorAll('[data-page]').forEach(b => b.classList.toggle('active', b.dataset.page===page));
  document.querySelector('#page-heading').textContent = pageTitle(page);
  const host = document.querySelector('#content'); host.innerHTML = '<div class="loading">جارٍ جلب البيانات من قاعدة البيانات…</div>';
  try {
    const renderer = ({dashboard: renderDashboard, organization: renderOrganization, approvals: renderApprovals,
      assets: renderAssets, pmo: renderPMO, scm: renderSCM, depreciation: renderDepreciation, ledger: renderLedger, hr: renderHR,
      finance: renderFinance, assetops: renderAssetOps, governance: renderGovernance, expansion: renderExpansion})[page];
    await renderer(host);
  } catch (error) {
    host.innerHTML = `<div class="empty-state"><div class="empty-icon">!</div><h3>تعذر تحميل هذه الشاشة</h3><p>${esc(cleanError(error))}</p><button class="secondary" id="retry">إعادة المحاولة</button></div>`;
    document.querySelector('#retry').onclick = () => loadPage(page);
  }
}
function statCard(label, value, hint, icon='◈') { return `<article class="stat-card"><div class="stat-head"><span>${label}</span><i>${icon}</i></div><strong>${value}</strong><small>${hint}</small></article>`; }
function table(headers, rows, empty='لا توجد سجلات في قاعدة البيانات حتى الآن') {
  if (!rows.length) return `<div class="empty-inline">${empty}</div>`;
  return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
}
async function renderDashboard(host) {
  const [dash, journals, assets, runs, units] = await Promise.all([
    queryPublic('app_finance_dashboard', 1), queryPublic('app_gl_journal_register', 8),
    queryPublic('app_asset_register', 8), queryPublic('app_depreciation_run_register', 8),
    queryRows('core','org_units',true,200)
  ]);
  const d = dash[0] || {};
  host.innerHTML = `<div class="welcome"><div><div class="eyebrow">مركز القيادة المؤسسي</div><h1>مرحباً بك في ${esc(state.tenant.display_name)}</h1><p>ملخص مباشر لما هو مسجل فعلياً في قاعدة الاختبار.</p></div><span class="env-tag">بيانات مباشرة · TEST</span></div><div class="stats-grid">${statCard('عدد القيود',fmtNumber(d.journal_count),'إجمالي سجل القيود','▤')}${statCard('القيود المرحلة',fmtNumber(d.posted_journal_count),'قيود مرحلة فعلياً','✓')}${statCard('إجمالي الأصول',fmtNumber(d.asset_count),'سجل الأصول الثابتة','▣')}${statCard('الوحدات التنظيمية',fmtNumber(units.length),'قطاعات وإدارات ومراكز تكلفة','⌘')}</div><div class="two-col"><section class="panel"><div class="panel-head"><div><h3>أحدث القيود المحاسبية</h3><p>من سجل دفتر الأستاذ العام</p></div><button class="link-button" data-jump="ledger">عرض الكل ←</button></div>${table(['رقم القيد','التاريخ','البيان','الحالة','المدين'],journals.slice(0,6).map(j=>`<tr><td>${esc(j.journal_no)}</td><td>${esc(j.journal_date)}</td><td>${esc(j.description)}</td><td>${statusPill(j.status)}</td><td>${fmtMoney(j.debit_total)}</td></tr>`))}</section><section class="panel"><div class="panel-head"><div><h3>ملخص مالي</h3><p>إجماليات القيود المرحلة فقط</p></div><span class="subtle-tag">SAR</span></div><div class="big-number">${fmtMoney(d.posted_debit_total)}</div><div class="muted">إجمالي المدين المرحّل</div><div class="metric-line"><span>إجمالي الدائن المرحّل</span><b>${fmtMoney(d.posted_credit_total)}</b></div><div class="metric-line"><span>قيود بانتظار الاعتماد</span><b>${fmtNumber(d.pending_approval_count)}</b></div><div class="metric-line"><span>دفعات إهلاك معتمدة</span><b>${fmtNumber(d.approved_depreciation_runs)}</b></div></section></div><div class="two-col"><section class="panel"><div class="panel-head"><div><h3>الأصول المسجلة</h3><p>أحدث الأصول في السجل</p></div><button class="link-button" data-jump="assets">عرض الأصول ←</button></div>${table(['رمز الأصل','اسم الأصل','التصنيف','التكلفة','الحالة'],assets.slice(0,5).map(a=>`<tr><td>${esc(a.asset_tag)}</td><td>${esc(a.name_ar)}</td><td>${esc(a.category_name_ar)}</td><td>${fmtMoney(a.acquisition_cost)}</td><td>${statusPill(a.status)}</td></tr>`))}</section><section class="panel"><div class="panel-head"><div><h3>دفعات الإهلاك</h3><p>آخر الدفعات المسجلة</p></div><button class="link-button" data-jump="depreciation">عرض الدفعات ←</button></div>${table(['رمز الدفعة','الفترة','الإهلاك','الحالة'],runs.slice(0,5).map(r=>`<tr><td>${esc(r.run_code)}</td><td>${esc(r.period_start)} – ${esc(r.period_end)}</td><td>${fmtMoney(r.total_depreciation)}</td><td>${statusPill(r.status)}</td></tr>`))}</section></div>`;
  host.querySelectorAll('[data-jump]').forEach(b=>b.onclick=()=>loadPage(b.dataset.jump));
}
async function renderOrganization(host) {
  const units = await queryRows('core','org_units',true,300);
  const rows = units.map(u=>`<tr><td>${esc(u.unit_code)}</td><td>${esc(u.unit_name)}</td><td>${esc(({sector:'قطاع',department:'إدارة',division:'قسم',section:'وحدة',branch:'فرع',cost_center:'مركز تكلفة'})[u.unit_type]||u.unit_type)}</td><td>${esc(units.find(x=>x.id===u.parent_id)?.unit_name||'—')}</td><td>${statusPill(u.is_active?'active':'inactive')}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>الهيكل المؤسسي</h1><p>الوحدات التنظيمية المحفوظة في قاعدة البيانات، مع إظهار الارتباطات الهرمية.</p></div><section class="panel">${table(['الرمز','اسم الوحدة','النوع','الوحدة الأم','الحالة'],rows)}</section>`;
}

async function renderPMO(host) {
  const [projects, tasks, milestones, units, memberships] = await Promise.all([
    queryRows('pmo','projects',true,500), queryRows('pmo','tasks',true,1500),
    queryRows('pmo','milestones',true,500), queryRows('core','org_units',true,300),
    queryRows('core','tenant_memberships',true,500)
  ]);
  const canManage = ['owner','admin','manager'].some(r=>state.roles.includes(r));
  const projectName = id => projects.find(p=>p.id===id)?.name || '—';
  const unitName = id => units.find(u=>u.id===id)?.unit_name || '—';
  const memberName = id => memberships.find(m=>m.id===id)?.user_id?.slice(0,8) || '—';
  const projectRows = projects.map(p=>{
    const related=tasks.filter(t=>t.project_id===p.id);
    const done=related.filter(t=>t.status==='done').length;
    return `<tr><td><b>${esc(p.project_code)}</b></td><td>${esc(p.name)}</td><td>${esc(unitName(p.org_unit_id))}</td><td>${statusPill(p.status)}</td><td>${statusPill(p.priority)}</td><td>${fmtNumber(p.progress_pct)}%</td><td>${fmtNumber(done)} / ${fmtNumber(related.length)}</td><td>${esc(p.planned_end||'—')}</td></tr>`;
  });
  const taskRows = tasks.map(t=>`<tr><td>${esc(t.task_code)}</td><td>${esc(projectName(t.project_id))}</td><td>${esc(t.title)}</td><td>${statusPill(t.status)}</td><td>${statusPill(t.priority)}</td><td>${esc(memberName(t.assigned_membership_id))}</td><td>${esc(t.due_date||'—')}</td></tr>`);
  const milestoneRows = milestones.map(m=>`<tr><td>${esc(m.milestone_code)}</td><td>${esc(projectName(m.project_id))}</td><td>${esc(m.name)}</td><td>${esc(m.due_date||'—')}</td><td>${statusPill(m.status)}</td></tr>`);
  const unitOptions = units.filter(u=>u.is_active).map(u=>`<option value="${esc(u.id)}">${esc(u.unit_code)} · ${esc(u.unit_name)}</option>`).join('');
  const projectOptions = projects.filter(p=>!['completed','cancelled'].includes(p.status)).map(p=>`<option value="${esc(p.id)}">${esc(p.project_code)} · ${esc(p.name)}</option>`).join('');
  const memberOptions = memberships.filter(m=>m.status==='active').map(m=>`<option value="${esc(m.id)}">${esc(m.id===state.membership?.id?'أنا (الحساب الحالي)':m.user_id.slice(0,8))}</option>`).join('');
  host.innerHTML = `<div class="section-intro"><h1>إدارة المشاريع ومكتب PMO</h1><p>سجل المشاريع، المهام، المراحل الرئيسية، والربط بالهيكل المؤسسي. جميع السجلات مقيدة بالمؤسسة الحالية عبر RLS.</p></div>
  <div class="stats-grid">${statCard('المشاريع',fmtNumber(projects.length),'سجل المشاريع','▣')}${statCard('المشاريع النشطة',fmtNumber(projects.filter(p=>p.status==='active').length),'قيد التنفيذ','↗')}${statCard('المهام المفتوحة',fmtNumber(tasks.filter(t=>!['done','cancelled'].includes(t.status)).length),'تحتاج متابعة','☷')}${statCard('المراحل الرئيسية',fmtNumber(milestones.length),'نقاط تسليم المشاريع','◷')}</div>
  ${canManage ? `<div class="two-col"><section class="panel"><div class="panel-head"><div><h3>إنشاء مشروع</h3><p>يُحفظ كسجل مخطط ويمكن تحديث حالته لاحقاً</p></div></div><form id="pmo-project-form" class="data-form"><label>رمز المشروع<input name="project_code" required maxlength="40" placeholder="PRJ-001"></label><label>اسم المشروع<input name="name" required maxlength="180" placeholder="اسم المشروع"></label><label>الإدارة / القطاع<select name="org_unit_id"><option value="">بدون ربط</option>${unitOptions}</select></label><label>مركز التكلفة<select name="cost_center_id"><option value="">بدون تحديد</option>${units.filter(u=>u.is_active&&u.unit_type==='cost_center').map(u=>`<option value="${esc(u.id)}">${esc(u.unit_code)} · ${esc(u.unit_name)}</option>`).join('')}</select></label><div class="form-row"><label>تاريخ البداية<input name="planned_start" type="date"></label><label>تاريخ النهاية<input name="planned_end" type="date"></label></div><div class="form-row"><label>الأولوية<select name="priority"><option value="normal">عادية</option><option value="low">منخفضة</option><option value="high">عالية</option><option value="critical">حرجة</option></select></label><label>الميزانية المعتمدة (ر.س)<input name="approved_budget" type="number" min="0" step="0.01"></label></div><label>وصف المشروع<textarea name="description" rows="2" placeholder="نطاق المشروع ومخرجاته"></textarea></label><button class="primary" type="submit">حفظ المشروع</button></form></section>
  <section class="panel"><div class="panel-head"><div><h3>إضافة مهمة</h3><p>اربط المهمة بمشروع قائم وحدد المسؤول والموعد</p></div></div>${projectOptions ? `<form id="pmo-task-form" class="data-form"><label>المشروع<select name="project_id" required>${projectOptions}</select></label><label>رمز المهمة<input name="task_code" required maxlength="40" placeholder="TASK-001"></label><label>عنوان المهمة<input name="title" required maxlength="180"></label><div class="form-row"><label>الأولوية<select name="priority"><option value="normal">عادية</option><option value="low">منخفضة</option><option value="high">عالية</option><option value="critical">حرجة</option></select></label><label>تاريخ الاستحقاق<input name="due_date" type="date"></label></div><label>المسؤول<select name="assigned_membership_id"><option value="">غير معيّن</option>${memberOptions}</select></label><label>الوصف<textarea name="description" rows="2"></textarea></label><button class="primary" type="submit">إضافة المهمة</button></form>` : `<div class="empty-inline">أنشئ مشروعاً أولاً لإضافة المهام.</div>`}</section></div>
  <section class="panel"><div class="panel-head"><div><h3>إضافة مرحلة رئيسية</h3><p>نقطة تسليم مرتبطة بمشروع</p></div></div>${projectOptions ? `<form id="pmo-milestone-form" class="data-form inline-form"><label>المشروع<select name="project_id" required>${projectOptions}</select></label><label>رمز المرحلة<input name="milestone_code" required placeholder="MS-001"></label><label>اسم المرحلة<input name="name" required></label><label>تاريخ الاستحقاق<input name="due_date" type="date"></label><button class="primary" type="submit">إضافة المرحلة</button></form>` : `<div class="empty-inline">لا توجد مشاريع بعد.</div>`}</section>` : `<div class="notice">حسابك يملك صلاحية العرض فقط في وحدة PMO. يلزم دور owner أو admin أو manager لإنشاء وتعديل السجلات.</div>`}
  <section class="panel"><div class="panel-head"><div><h3>محفظة المشاريع</h3><p>${fmtNumber(projects.length)} مشروعاً مسجلاً</p></div></div>${table(['الرمز','المشروع','الوحدة التنظيمية','الحالة','الأولوية','الإنجاز','المهام المنجزة','النهاية المخططة'],projectRows)}</section>
  <section class="panel"><div class="panel-head"><div><h3>المهام</h3><p>${fmtNumber(tasks.length)} مهمة</p></div></div>${table(['الرمز','المشروع','المهمة','الحالة','الأولوية','المسؤول (معرّف مختصر)','الاستحقاق'],taskRows)}</section>
  <section class="panel"><div class="panel-head"><div><h3>المراحل الرئيسية</h3><p>${fmtNumber(milestones.length)} مرحلة</p></div></div>${table(['الرمز','المشروع','المرحلة','الاستحقاق','الحالة'],milestoneRows)}</section>
  <div class="notice">حالة الوحدة: قاعدة البيانات مهيأة. لا توجد مشاريع فعلية مسجلة حتى الآن. لم يتم إنشاء بيانات تجريبية أو ميزانيات أو التزامات مالية تلقائية.</div>`;

  const projectForm=host.querySelector('#pmo-project-form');
  if(projectForm) projectForm.onsubmit=async e=>{
    e.preventDefault(); const f=new FormData(projectForm); const payload={tenant_id:state.tenant.id,project_code:f.get('project_code').trim(),name:f.get('name').trim(),description:f.get('description')||null,org_unit_id:f.get('org_unit_id')||null,cost_center_id:f.get('cost_center_id')||null,owner_membership_id:state.membership?.id||null,status:'planned',priority:f.get('priority'),planned_start:f.get('planned_start')||null,planned_end:f.get('planned_end')||null,approved_budget:f.get('approved_budget')?Number(f.get('approved_budget')):null,created_by:state.user.id};
    const {error}=await supabase.schema('pmo').from('projects').insert(payload); if(error){toast(cleanError(error),'error');return;} toast('تم حفظ المشروع في قاعدة الاختبار.','success'); await loadPage('pmo');
  };
  const taskForm=host.querySelector('#pmo-task-form');
  if(taskForm) taskForm.onsubmit=async e=>{
    e.preventDefault(); const f=new FormData(taskForm); const payload={tenant_id:state.tenant.id,project_id:f.get('project_id'),task_code:f.get('task_code').trim(),title:f.get('title').trim(),description:f.get('description')||null,priority:f.get('priority'),due_date:f.get('due_date')||null,assigned_membership_id:f.get('assigned_membership_id')||null,status:'backlog',created_by:state.user.id};
    const {error}=await supabase.schema('pmo').from('tasks').insert(payload); if(error){toast(cleanError(error),'error');return;} toast('تمت إضافة المهمة.','success'); await loadPage('pmo');
  };
  const milestoneForm=host.querySelector('#pmo-milestone-form');
  if(milestoneForm) milestoneForm.onsubmit=async e=>{
    e.preventDefault(); const f=new FormData(milestoneForm); const payload={tenant_id:state.tenant.id,project_id:f.get('project_id'),milestone_code:f.get('milestone_code').trim(),name:f.get('name').trim(),due_date:f.get('due_date')||null,status:'pending',created_by:state.user.id};
    const {error}=await supabase.schema('pmo').from('milestones').insert(payload); if(error){toast(cleanError(error),'error');return;} toast('تمت إضافة المرحلة الرئيسية.','success'); await loadPage('pmo');
  };
}

async function renderApprovals(host) {
  const [requests, steps] = await Promise.all([queryRows('workflow','approval_requests',true,250),queryRows('workflow','approval_steps',true,500)]);
  const canDecide=['owner','admin'].some(r=>state.roles.includes(r));
  const typeLabel = t => ({purchase_request:'طلب شراء',supplier_approval:'اعتماد مورد',purchase_order:'أمر شراء'}[t]||t);
  const rows = requests.map(r=>{const st=steps.filter(x=>x.request_id===r.id);return `<tr><td>${esc(typeLabel(r.request_type))}</td><td>${esc(r.subject)}</td><td>${esc(r.created_at?.slice(0,10))}</td><td>${statusPill(r.status)}</td><td>${esc(st.map(x=>`${x.step_order}: ${x.status}`).join('، ')||'—')}</td><td>${esc(r.decision_note||'—')}</td><td>${canDecide&&r.status==='pending'?`<button class="mini-action" data-decision="approved" data-request="${esc(r.id)}">اعتماد</button> <button class="mini-action" data-decision="rejected" data-request="${esc(r.id)}">رفض</button>`:'—'}</td></tr>`;});
  host.innerHTML = `<div class="section-intro"><h1>الموافقات</h1><p>مركز موحد لاعتماد الموردين وطلبات الشراء وأوامر الشراء. قرار الاعتماد يحدث سجل المشتريات المرتبط تلقائياً.</p></div><section class="panel">${table(['نوع الطلب','الموضوع','تاريخ الإنشاء','الحالة','الخطوات','ملاحظة القرار','الإجراء'],rows)}</section>`;
  host.querySelectorAll('[data-decision]').forEach(btn=>btn.onclick=async()=>{const note=prompt('أدخل ملاحظة القرار (اختياري):')||'';if(!confirm(btn.dataset.decision==='approved'?'تأكيد اعتماد الطلب؟':'تأكيد رفض الطلب؟'))return;btn.disabled=true;const {error}=await supabase.schema('workflow').rpc('decide_request',{p_request_id:btn.dataset.request,p_decision:btn.dataset.decision,p_note:note});if(error){toast(cleanError(error),'error');btn.disabled=false;return;}toast(btn.dataset.decision==='approved'?'تم اعتماد الطلب وتحديث الوحدة المرتبطة.':'تم رفض الطلب وتحديث الوحدة المرتبطة.','success');await loadPage('approvals');});
}
async function renderAssets(host) {
  const assets = await queryPublic('app_asset_register',250);
  const rows = assets.map(a=>`<tr><td>${esc(a.asset_tag)}</td><td>${esc(a.name_ar)}</td><td>${esc(a.category_name_ar)}</td><td>${esc(a.acquired_on)}</td><td>${fmtMoney(a.acquisition_cost)}</td><td>${esc(a.cost_center_name||'—')}</td><td>${statusPill(a.status)}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>سجل الأصول الثابتة</h1><p>عرض مباشر للأصول وتصنيفاتها وتكلفتها ومراكز تكلفتها.</p></div><section class="panel">${table(['رمز الأصل','الأصل','التصنيف','تاريخ الاقتناء','التكلفة','مركز التكلفة','الحالة'],rows)}</section>`;
}
async function renderDepreciation(host) {
  const [runs, years] = await Promise.all([queryPublic('app_depreciation_run_register',200), queryRows('finance','fiscal_years',true,50)]);
  const rows = runs.map(r=>`<tr><td>${esc(r.run_code)}</td><td>${esc(r.period_start)} – ${esc(r.period_end)}</td><td>${fmtNumber(r.asset_line_count)}</td><td>${fmtMoney(r.total_depreciation)}</td><td>${statusPill(r.status)}</td><td>${esc(r.journal_no||'—')}</td><td>${statusPill(r.journal_status)}</td><td>${r.status==='approved'&&!r.journal_id?`<button class="mini-action" data-run="${esc(r.id)}">إنشاء قيد مسودة</button>`:'—'}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>إدارة الإهلاك</h1><p>متابعة دفعات الإهلاك وربط الدفعة المعتمدة بقيد محاسبي مسودة. لا يتم الترحيل تلقائياً.</p></div><section class="panel"><div class="panel-head"><div><h3>دفعات الإهلاك</h3><p>اختر السنة المالية لإنشاء قيد مسودة للدفعة المعتمدة</p></div><select id="fiscal-year"><option value="">اختر السنة المالية</option>${years.map(y=>`<option value="${esc(y.id)}">${esc(y.year_code||y.name||y.id.slice(0,8))}</option>`).join('')}</select></div>${table(['رمز الدفعة','الفترة','عدد الأصول','قيمة الإهلاك','حالة الدفعة','رقم القيد','حالة القيد','إجراء'],rows)}</section>`;
  host.querySelectorAll('[data-run]').forEach(btn=>btn.onclick=async()=>{
    const fiscalYearId=host.querySelector('#fiscal-year').value; if(!fiscalYearId){toast('اختر السنة المالية أولاً','error');return;}
    btn.disabled=true; const {error}=await supabase.rpc('app_create_depreciation_journal',{p_run_id:btn.dataset.run,p_fiscal_year_id:fiscalYearId});
    if(error){toast(cleanError(error),'error');btn.disabled=false;}else{toast('تم إنشاء قيد مسودة. راجعه قبل الإرسال والاعتماد.','success');await loadPage('depreciation');}
  });
}
async function renderLedger(host) {
  const [journals, lines] = await Promise.all([queryPublic('app_gl_journal_register',300), queryPublic('app_gl_journal_lines',600)]);
  const rows = journals.map(j=>{
    const actions = ['submit','approve','post'].filter(a=>canTransition(state.roles,a) && ({draft:['submit'],submitted:['approve'],approved:['post']}[j.status]||[]).includes(a));
    return `<tr><td>${esc(j.journal_no)}</td><td>${esc(j.journal_date)}</td><td>${esc(j.description)}</td><td>${esc(j.source_type)}</td><td>${fmtMoney(j.debit_total)}</td><td>${fmtMoney(j.credit_total)}</td><td>${statusPill(j.status)}</td><td>${actions.map(a=>`<button class="mini-action" data-journal="${esc(j.id)}" data-action="${a}">${({submit:'إرسال',approve:'اعتماد',post:'ترحيل'})[a]}</button>`).join(' ')||'—'}</td></tr>`;
  });
  host.innerHTML = `<div class="section-intro"><h1>دفتر الأستاذ العام</h1><p>سجل القيود وتفاصيلها. مسار الترحيل يفرض توازن المدين والدائن وفصل المنشئ عن المعتمد داخل قاعدة البيانات.</p></div><section class="panel"><div class="panel-head"><div><h3>سجل القيود</h3><p>${fmtNumber(journals.length)} قيداً · ${fmtNumber(lines.length)} سطراً</p></div><span class="subtle-tag">SAR</span></div>${table(['رقم القيد','التاريخ','البيان','المصدر','مدين','دائن','الحالة','إجراء'],rows)}</section><section class="panel"><div class="panel-head"><div><h3>تفاصيل آخر القيود</h3><p>سطور الأستاذ العام</p></div></div>${table(['القيد','الحساب','مركز التكلفة','البيان','مدين','دائن'],lines.slice(0,80).map(l=>`<tr><td>${esc(l.journal_id?.slice(0,8))}</td><td>${esc(l.account_code)} · ${esc(l.account_name_ar)}</td><td>${esc(l.cost_center_code||'—')}</td><td>${esc(l.description||'—')}</td><td>${fmtMoney(l.debit)}</td><td>${fmtMoney(l.credit)}</td></tr>`))}</section>`;
  host.querySelectorAll('[data-journal]').forEach(btn=>btn.onclick=async()=>{
    btn.disabled=true; const {error}=await supabase.rpc('app_transition_gl_journal',{p_journal_id:btn.dataset.journal,p_action:btn.dataset.action});
    if(error){toast(cleanError(error),'error');btn.disabled=false;}else{toast('تم تنفيذ الإجراء في قاعدة البيانات.','success');await loadPage('ledger');}
  });
}
async function renderHR(host) {
  const positions = await queryRows('hr','positions',true,250);
  const rows = positions.map(p=>`<tr><td>${esc(p.position_code)}</td><td>${esc(p.position_name_ar||p.position_name||'—')}</td><td>${esc(p.employment_type)}</td><td>${esc(p.work_model)}</td><td>${esc(p.salary_min==null?'—':fmtMoney(p.salary_min))} – ${esc(p.salary_max==null?'—':fmtMoney(p.salary_max))}</td><td>${statusPill(p.status)}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>الوظائف والموارد البشرية</h1><p>عرض الوظائف المخططة ونطاقات الرواتب عند توفرها. لا توجد تعيينات فعلية في بيئة الاختبار.</p></div><section class="panel">${table(['رمز الوظيفة','المسمى','نوع العمل','نموذج العمل','نطاق الراتب','الحالة'],rows)}</section>`;
}


async function renderFinance(host) {
  const [accounts, years, budgets, lines] = await Promise.all([
    queryRows('finance','accounts',true,500), queryRows('finance','fiscal_years',true,100),
    queryRows('finance','budgets',true,200), queryRows('finance','budget_lines',true,1000)
  ]);
  const budgetRows = budgets.map(b => {
    const total = lines.filter(l => l.budget_id === b.id).reduce((a,l)=>a+Number(l.amount||0),0);
    return `<tr><td>${esc(b.budget_code)}</td><td>${esc(b.name_ar)}</td><td>${esc(years.find(y=>y.id===b.fiscal_year_id)?.name_ar || years.find(y=>y.id===b.fiscal_year_id)?.year_code || '—')}</td><td>${fmtMoney(total)}</td><td>${statusPill(b.status)}</td><td>${esc(b.version_no)}</td></tr>`;
  });
  const accountRows = accounts.map(a=>`<tr><td>${esc(a.account_code)}</td><td>${esc(a.name_ar)}</td><td>${esc(a.account_type)}</td><td>${esc(a.normal_balance)}</td><td>${statusPill(a.is_active?'active':'inactive')}</td><td>${a.is_postable?'نعم':'لا'}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>الميزانيات ودليل الحسابات</h1><p>قراءة مباشرة لدليل الحسابات والسنوات المالية والميزانيات وسطورها. لا يتم إنشاء ميزانيات أو تعديلها من هذه الشاشة في هذا الإصدار.</p></div><div class="stats-grid">${statCard('الحسابات',fmtNumber(accounts.length),'دليل الحسابات','▤')}${statCard('السنوات المالية',fmtNumber(years.length),'سنوات مسجلة','◷')}${statCard('الميزانيات',fmtNumber(budgets.length),'نسخ الميزانية','▦')}${statCard('سطور الميزانية',fmtNumber(lines.length),'توزيعات الفترات','≋')}</div><section class="panel"><div class="panel-head"><div><h3>الميزانيات</h3><p>إجمالي السطور المسجلة لكل ميزانية</p></div></div>${table(['الرمز','الميزانية','السنة المالية','إجمالي التوزيع','الحالة','الإصدار'],budgetRows)}</section><section class="panel"><div class="panel-head"><div><h3>دليل الحسابات</h3><p>الحسابات القابلة للترحيل وغير القابلة للترحيل</p></div></div>${table(['رمز الحساب','اسم الحساب','النوع','الرصيد الطبيعي','الحالة','قابل للترحيل'],accountRows)}</section>`;
}
async function renderAssetOps(host) {
  const [moves, maintenance, sessions, stockLines, assets] = await Promise.all([
    queryRows('assets','asset_movements',true,300), queryRows('assets','maintenance_records',true,300),
    queryRows('assets','stocktake_sessions',true,150), queryRows('assets','stocktake_lines',true,500),
    queryRows('assets','asset_register',true,500)
  ]);
  const assetName = id => assets.find(a=>a.id===id)?.name_ar || id?.slice(0,8) || '—';
  const moveRows = moves.map(m=>`<tr><td>${esc(m.movement_date)}</td><td>${esc(assetName(m.asset_id))}</td><td>${esc(m.movement_type)}</td><td>${esc(m.reference_no||'—')}</td><td>${esc(m.notes||'—')}</td></tr>`);
  const maintRows = maintenance.map(m=>`<tr><td>${esc(assetName(m.asset_id))}</td><td>${esc(m.maintenance_type)}</td><td>${esc(m.scheduled_on)}</td><td>${fmtMoney(m.cost)}</td><td>${statusPill(m.status)}</td><td>${esc(m.provider_name||'—')}</td></tr>`);
  const stockRows = sessions.map(x=>`<tr><td>${esc(x.session_code)}</td><td>${esc(x.title_ar)}</td><td>${esc(x.stocktake_date)}</td><td>${fmtNumber(stockLines.filter(l=>l.session_id===x.id).length)}</td><td>${statusPill(x.status)}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>تشغيل الأصول والجرد</h1><p>متابعة حركات العهد والصيانة وجلسات الجرد من السجلات الموجودة في قاعدة الاختبار. هذه الشاشة للعرض والمتابعة فقط.</p></div><div class="stats-grid">${statCard('حركات الأصول',fmtNumber(moves.length),'سجل الحركة','↔')}${statCard('أوامر الصيانة',fmtNumber(maintenance.length),'سجلات الصيانة','⚙')}${statCard('جلسات الجرد',fmtNumber(sessions.length),'عمليات الجرد','▣')}${statCard('نتائج الجرد',fmtNumber(stockLines.length),'سطور العد','✓')}</div><section class="panel"><h3>حركات الأصول</h3>${table(['التاريخ','الأصل','نوع الحركة','المرجع','ملاحظات'],moveRows)}</section><section class="panel"><h3>الصيانة</h3>${table(['الأصل','النوع','التاريخ المجدول','التكلفة','الحالة','المورد'],maintRows)}</section><section class="panel"><h3>جلسات الجرد</h3>${table(['الرمز','الجلسة','التاريخ','عدد البنود','الحالة'],stockRows)}</section>`;
}
async function renderGovernance(host) {
  const [events, memberships, roles] = await Promise.all([
    queryRows('audit','events',true,300), queryRows('core','tenant_memberships',true,300),
    queryRows('core','membership_roles',true,500)
  ]);
  const memberRows = memberships.map(m=>`<tr><td>${esc(m.user_id.slice(0,8))}…</td><td>${esc(m.status)}</td><td>${esc(m.joined_at?.slice(0,10)||'—')}</td><td>${esc(roles.filter(r=>r.membership_id===m.id).map(r=>r.role_key).join('، ')||'—')}</td></tr>`);
  const eventRows = events.map(e=>`<tr><td>${esc(e.occurred_at?.replace('T',' ').slice(0,19))}</td><td>${esc(e.event_type)}</td><td>${esc([e.entity_schema,e.entity_name].filter(Boolean).join('.'))}</td><td>${esc(e.entity_id||'—')}</td><td>${esc(e.actor_user_id?.slice(0,8)||'—')}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>الحوكمة وسجل التدقيق</h1><p>مراجعة العضويات والأدوار وسجل الأحداث. إدارة الأدوار والتفويضات لا تتم من هذه الشاشة.</p></div><div class="stats-grid">${statCard('العضويات',fmtNumber(memberships.length),'ضمن المؤسسة الحالية','♙')}${statCard('العضويات النشطة',fmtNumber(memberships.filter(m=>m.status==='active').length),'حالة نشطة','✓')}${statCard('تعيينات الأدوار',fmtNumber(roles.length),'أدوار مسندة','⌘')}${statCard('أحداث التدقيق',fmtNumber(events.length),'سجل الأحداث المتاح','◉')}</div><section class="panel"><h3>العضويات والأدوار</h3>${table(['معرّف المستخدم','الحالة','تاريخ الانضمام','الأدوار'],memberRows)}</section><section class="panel"><h3>سجل التدقيق</h3>${table(['التوقيت','نوع الحدث','الكيان','معرّف السجل','المنفذ'],eventRows)}</section>`;
}
async function renderSCM(host) {
  const [suppliers, requests, requestLines, rfqs, invitations, quotes, quoteLines, orders, orderLines, receipts, receiptLines, projects, units, budgets, budgetLines, evaluations, commitments, warehouses, items, balances, movements, operations, operationLines] = await Promise.all([
    queryRows('scm','suppliers',true,500), queryRows('scm','purchase_requests',true,500),
    queryRows('scm','purchase_request_lines',true,1200), queryRows('scm','rfqs',true,400),
    queryRows('scm','rfq_suppliers',true,1000), queryRows('scm','supplier_quotes',true,800),
    queryRows('scm','supplier_quote_lines',true,1200), queryRows('scm','purchase_orders',true,500),
    queryRows('scm','purchase_order_lines',true,1200), queryRows('scm','goods_receipts',true,500),
    queryRows('scm','goods_receipt_lines',true,1200), queryRows('pmo','projects',true,500),
    queryRows('core','org_units',true,300), queryRows('finance','budgets',true,200),
    queryRows('finance','budget_lines',true,1500), queryRows('scm','quote_evaluations',true,800),
    queryRows('scm','budget_commitments',true,1200), queryRows('scm','warehouses',true,300),
    queryRows('scm','inventory_items',true,1000), queryRows('scm','inventory_balances',true,1500),
    queryRows('scm','inventory_movements',true,2000), queryRows('scm','inventory_operations',true,1000),
    queryRows('scm','inventory_operation_lines',true,2000)
  ]);
  const canBuy = ['owner','admin','manager','procurement_manager','buyer'].some(r=>state.roles.includes(r));
  const canSupplier = ['owner','admin','procurement_manager'].some(r=>state.roles.includes(r));
  const canOrder = ['owner','admin','procurement_manager'].some(r=>state.roles.includes(r));
  const canReceive = ['owner','admin','warehouse_manager','procurement_manager'].some(r=>state.roles.includes(r));
  const canInventory = ['owner','admin'].some(r=>state.roles.includes(r));
  const projectName = id => projects.find(x=>x.id===id)?.name || '—';
  const unitName = id => units.find(x=>x.id===id)?.unit_name || '—';
  const supplierName = id => suppliers.find(x=>x.id===id)?.display_name || suppliers.find(x=>x.id===id)?.legal_name || '—';
  const requestName = id => requests.find(x=>x.id===id)?.title || '—';
  const rfqName = id => rfqs.find(x=>x.id===id)?.rfq_no || '—';
  const budgetLineLabel = l => `${budgets.find(b=>b.id===l.budget_id)?.budget_code || 'ميزانية'} · ${fmtMoney(l.amount)}`;
  const projectOpts = projects.filter(p=>!['completed','cancelled'].includes(p.status)).map(p=>`<option value="${esc(p.id)}">${esc(p.project_code)} · ${esc(p.name)}</option>`).join('');
  const unitOpts = units.filter(u=>u.is_active && u.unit_type!=='cost_center').map(u=>`<option value="${esc(u.id)}">${esc(u.unit_code)} · ${esc(u.unit_name)}</option>`).join('');
  const costOpts = units.filter(u=>u.is_active && u.unit_type==='cost_center').map(u=>`<option value="${esc(u.id)}">${esc(u.unit_code)} · ${esc(u.unit_name)}</option>`).join('');
  const supplierOpts = suppliers.filter(s=>s.approval_status==='approved').map(s=>`<option value="${esc(s.id)}">${esc(s.display_name||s.legal_name)}</option>`).join('');
  const requestOpts = requests.filter(r=>r.status==='approved').map(r=>`<option value="${esc(r.id)}">${esc(r.request_no)} · ${esc(r.title)}</option>`).join('');
  const budgetOpts = budgetLines.map(l=>`<option value="${esc(l.id)}">${esc(budgetLineLabel(l))}</option>`).join('');
  const itemOpts = items.filter(i=>i.is_active).map(i=>`<option value="${esc(i.id)}">${esc(i.sku)} · ${esc(i.name_ar)}</option>`).join('');
  const warehouseOpts = warehouses.filter(w=>w.is_active).map(w=>`<option value="${esc(w.id)}">${esc(w.warehouse_code)} · ${esc(w.name_ar)}</option>`).join('');
  const stockItemOpts = items.filter(i=>i.is_active && i.item_type==='stock').map(i=>`<option value="${esc(i.id)}">${esc(i.sku)} · ${esc(i.name_ar)} (${esc(i.unit)})</option>`).join('');
  const operationRows = operations.map(o=>{const ls=operationLines.filter(l=>l.operation_id===o.id);return `<tr><td>${esc(o.operation_no)}</td><td>${esc(o.title)}</td><td>${({issue:'صرف',transfer:'تحويل',stocktake:'جرد'})[o.operation_type]||esc(o.operation_type)}</td><td>${fmtNumber(ls.length)}</td><td>${esc(o.created_at?.slice(0,10)||'—')}</td><td>${statusPill(o.status)}</td></tr>`;});
  const supplierRows = suppliers.map(s=>`<tr><td>${esc(s.supplier_code)}</td><td>${esc(s.display_name||s.legal_name)}</td><td>${esc(s.category||'—')}</td><td>${esc(s.phone||s.email||'—')}</td><td>${statusPill(s.approval_status)}</td><td>${esc(s.payment_terms_days==null?'—':`${s.payment_terms_days} يوم`)}</td><td>${canSupplier && s.approval_status==='pending' && !s.approval_request_id?`<button class="mini-action" data-submit-supplier="${esc(s.id)}">إرسال للاعتماد</button>`:'—'}</td></tr>`);
  const requestRows = requests.map(r=>`<tr><td><b>${esc(r.request_no)}</b></td><td>${esc(r.title)}</td><td>${esc(projectName(r.project_id))}</td><td>${esc(unitName(r.cost_center_id))}</td><td>${fmtMoney(r.estimated_total)}</td><td>${statusPill(r.status)}</td><td>${esc(r.needed_by||'—')}</td><td>${canBuy && r.status==='draft'?`<button class="mini-action" data-submit-pr="${esc(r.id)}">إرسال للموافقة</button>`:'—'}</td></tr>`);
  const rfqRows = rfqs.map(r=>`<tr><td>${esc(r.rfq_no)}</td><td>${esc(requestName(r.request_id))}</td><td>${esc(r.issue_date)}</td><td>${esc(r.closing_date||'—')}</td><td>${fmtNumber(invitations.filter(i=>i.rfq_id===r.id).length)}</td><td>${statusPill(r.status)}</td><td>${canBuy && r.status==='draft' && invitations.some(i=>i.rfq_id===r.id)?`<button class="mini-action" data-issue-rfq="${esc(r.id)}">إصدار المنافسة</button>`:'—'}</td></tr>`);
  const quoteRows = quotes.map(q=>{const ev=evaluations.find(x=>x.quote_id===q.id);return `<tr><td>${esc(q.quote_no||q.id.slice(0,8))}</td><td>${esc(rfqName(q.rfq_id))}</td><td>${esc(supplierName(q.supplier_id))}</td><td>${fmtMoney(q.total_amount)}</td><td>${esc(q.delivery_days==null?'—':`${q.delivery_days} يوم`)}</td><td>${ev?`${fmtNumber(ev.technical_score)} / ${fmtNumber(ev.commercial_score)} / ${fmtNumber(ev.delivery_score)}`:'—'}</td><td>${statusPill(q.status)}</td></tr>`;});
  const orderRows = orders.map(o=>`<tr><td>${esc(o.order_no)}</td><td>${esc(requestName(o.request_id))}</td><td>${esc(supplierName(o.supplier_id))}</td><td>${fmtMoney(o.total_amount)}</td><td>${esc(o.expected_delivery_date||'—')}</td><td>${statusPill(o.status)}</td><td>${o.status==='draft'&&canOrder&&orderLines.some(l=>l.order_id===o.id)?`<button class="mini-action" data-submit-po="${esc(o.id)}">إرسال للاعتماد</button>`:o.status==='approved'&&canOrder?`<button class="mini-action" data-issue-po="${esc(o.id)}">إصدار الأمر</button>`:'—'}</td></tr>`);
  const receiptRows = receipts.map(r=>`<tr><td>${esc(r.receipt_no)}</td><td>${esc(orders.find(o=>o.id===r.order_id)?.order_no||'—')}</td><td>${esc(r.received_on)}</td><td>${fmtNumber(receiptLines.filter(x=>x.receipt_id===r.id).length)}</td><td>${statusPill(r.status)}</td></tr>`);
  host.innerHTML = `<div class="section-intro"><h1>المشتريات وسلسلة الإمداد</h1><p>دورة شراء مترابطة مع المشاريع ومراكز التكلفة وبنود الميزانية والموردين. الإنشاءات تحفظ كمسودات؛ الاعتماد وإصدار أوامر الشراء والاستلام يخضع لصلاحيات ومسارات الاعتماد.</p></div>
  <div class="stats-grid">${statCard('الموردون',fmtNumber(suppliers.length),'ملفات الموردين','♙')}${statCard('طلبات الشراء',fmtNumber(requests.length),'طلبات مرتبطة بالمشاريع','▤')}${statCard('طلبات عروض الأسعار',fmtNumber(rfqs.length),'المنافسات المفتوحة','≋')}${statCard('أوامر الشراء',fmtNumber(orders.length),'أوامر مسجلة','▣')}</div>
  <div class="stats-grid">${statCard('قيمة الطلبات',fmtMoney(requests.reduce((a,x)=>a+Number(x.estimated_total||0),0)),'تقديري · SAR','ر.س')}${statCard('العروض المستلمة',fmtNumber(quotes.length),'عروض الموردين','⇄')}${statCard('الاستلامات',fmtNumber(receipts.length),'محاضر الاستلام','✓')}${statCard('بانتظار مراجعة المورد',fmtNumber(suppliers.filter(s=>s.approval_status==='pending').length),'ملفات غير معتمدة','◷')}</div>
  <div class="notice">تنبيه تشغيلي: لا توجد ميزانيات فعلية معتمدة أو بيانات موردين تشغيلية في بيئة الاختبار حالياً. ربط بند الميزانية هنا مرجعي؛ فحص الرصيد المتاح وحجز الاعتماد المالي سيُستكملان ضمن محرك الالتزامات والموافقات قبل السماح بإصدار أمر شراء.</div>
  ${canSupplier?`<section class="panel"><div class="panel-head"><div><h3>تسجيل مورد</h3><p>يُنشأ المورد بحالة «بانتظار المراجعة» ولا يصبح مؤهلاً للشراء قبل اعتماده</p></div></div><form id="scm-supplier-form" class="data-form"><div class="form-row"><label>رمز المورد<input name="supplier_code" required maxlength="40" placeholder="SUP-001"></label><label>الاسم القانوني<input name="legal_name" required maxlength="180"></label></div><div class="form-row"><label>الاسم التجاري / المختصر<input name="display_name" maxlength="180"></label><label>تصنيف المورد<input name="category" maxlength="80" placeholder="تقنية، أجهزة، خدمات…"></label></div><div class="form-row"><label>اسم جهة الاتصال<input name="contact_name"></label><label>رقم الهاتف<input name="phone" type="tel"></label></div><div class="form-row"><label>البريد الإلكتروني<input name="email" type="email"></label><label>مدة السداد (يوم)<input name="payment_terms_days" type="number" min="0" max="365"></label></div><div class="form-row"><label>الرقم الضريبي<input name="tax_registration_no"></label><label>السجل التجاري<input name="commercial_registration_no"></label></div><label>العنوان<input name="address_text"></label><button class="primary" type="submit">حفظ ملف المورد للمراجعة</button></form></section>`:''}
  ${canBuy?`<section class="panel"><div class="panel-head"><div><h3>إنشاء طلب شراء</h3><p>اربط الاحتياج بمشروع ووحدة تنظيمية ومركز تكلفة وبند ميزانية عند توفره</p></div><span class="subtle-tag">مسودة فقط</span></div><form id="scm-pr-form" class="data-form"><div class="form-row"><label>رقم الطلب<input name="request_no" required placeholder="PR-2026-001"></label><label>عنوان الطلب<input name="title" required placeholder="وصف مختصر للاحتياج"></label></div><div class="form-row"><label>المشروع<select name="project_id"><option value="">بدون مشروع</option>${projectOpts}</select></label><label>الإدارة / القطاع<select name="org_unit_id"><option value="">بدون ربط</option>${unitOpts}</select></label></div><div class="form-row"><label>مركز التكلفة<select name="cost_center_id"><option value="">اختر مركز التكلفة</option>${costOpts}</select></label><label>تاريخ الاحتياج<input name="needed_by" type="date"></label></div><div class="form-row"><label>الأولوية<select name="priority"><option value="normal">عادية</option><option value="low">منخفضة</option><option value="high">عالية</option><option value="critical">حرجة</option></select></label><label>بند الميزانية<select name="budget_line_id"><option value="">غير محدد</option>${budgetOpts}</select></label></div><div class="form-row"><label>الصنف المخزني (اختياري)<select name="item_id"><option value="">خدمة / بند غير مخزني</option>${itemOpts}</select></label><label>وصف الصنف / الخدمة<input name="line_description" required></label></div><label>الوحدة<input name="unit" value="unit" required></label><div class="form-row"><label>الكمية<input name="quantity" type="number" min="0.001" step="0.001" value="1" required></label><label>السعر التقديري للوحدة (ر.س)<input name="estimated_unit_price" type="number" min="0" step="0.01" value="0" required></label></div><label>ملاحظات<textarea name="description" rows="2"></textarea></label><button class="primary" type="submit">حفظ طلب الشراء كمسودة</button></form></section>`:''}
  ${canReceive?`<section class="panel"><div class="panel-head"><div><h3>تهيئة المستودعات والأصناف</h3><p>إنشاء مواقع التخزين والأصناف وربطها بطلبات الشراء لتحديث الأرصدة عند الاستلام المقبول</p></div></div><div class="two-col"><form id="scm-warehouse-form" class="data-form"><h4>إضافة مستودع</h4><label>رمز المستودع<input name="warehouse_code" required placeholder="WH-MAK-01"></label><label>اسم المستودع<input name="name_ar" required></label><label>الموقع<input name="location_text"></label><button class="primary" type="submit">حفظ المستودع</button></form><form id="scm-item-form" class="data-form"><h4>إضافة صنف</h4><label>رمز الصنف / SKU<input name="sku" required></label><label>اسم الصنف<input name="name_ar" required></label><div class="form-row"><label>نوع البند<select name="item_type"><option value="stock">مخزني</option><option value="non_stock">غير مخزني</option><option value="service">خدمة</option></select></label><label>وحدة القياس<input name="unit" value="unit" required></label></div><label>حد إعادة الطلب<input name="minimum_stock" type="number" min="0" step="0.001" value="0"></label><button class="primary" type="submit">حفظ الصنف</button></form></div></section>`:''}
  <section class="panel"><div class="panel-head"><div><h3>ملفات الموردين</h3><p>اعتماد المورد شرط لإنشاء أمر شراء</p></div></div>${table(['الرمز','المورد','التصنيف','التواصل','حالة الاعتماد','شروط السداد','الإجراء'],supplierRows)}</section>
  <section class="panel"><div class="panel-head"><div><h3>طلبات الشراء</h3><p>تتبع الاحتياج والتكلفة والربط بالمشاريع</p></div></div>${table(['رقم الطلب','العنوان','المشروع','مركز التكلفة','التكلفة التقديرية','الحالة','تاريخ الاحتياج','الإجراء'],requestRows)}</section>
  ${canBuy?`<section class="panel"><div class="panel-head"><div><h3>إنشاء طلب عروض أسعار RFQ</h3><p>إرسال الدعوات للموردين المعتمدين المختارين يدوياً بعد إنشاء الطلب</p></div></div><form id="scm-rfq-form" class="data-form"><div class="form-row"><label>رقم المنافسة<input name="rfq_no" required placeholder="RFQ-2026-001"></label><label>طلب الشراء<select name="request_id" required>${requestOpts}</select></label></div><div class="form-row"><label>عنوان المنافسة<input name="title" required></label><label>تاريخ إغلاق العروض<input name="closing_date" type="date"></label></div><label>الموردون المدعوون (اختيار متعدد)<select name="supplier_ids" multiple size="4">${supplierOpts}</select></label><button class="primary" type="submit">إنشاء طلب العروض والدعوات</button></form></section>`:''}
  <section class="panel"><div class="panel-head"><div><h3>طلبات عروض الأسعار</h3><p>الموردون المدعوون وحالة المنافسة</p></div></div>${table(['رقم RFQ','طلب الشراء','تاريخ الإصدار','الإغلاق','عدد الدعوات','الحالة','الإجراء'],rfqRows)}</section>
  ${canBuy?`<section class="panel"><div class="panel-head"><div><h3>تسجيل عرض مورد</h3><p>تسجيل العرض للمقارنة ثم ترسية العرض المختار يدوياً</p></div></div><form id="scm-quote-form" class="data-form"><div class="form-row"><label>طلب العروض<select name="rfq_id" required>${rfqs.filter(r=>['issued','closed'].includes(r.status)).map(r=>`<option value="${esc(r.id)}">${esc(r.rfq_no)}</option>`).join('')}</select></label><label>المورد المدعو<select name="supplier_id" required>${supplierOpts}</select></label></div><div class="form-row"><label>رقم عرض المورد<input name="quote_no"></label><label>القيمة الإجمالية (ر.س)<input name="total_amount" type="number" min="0" step="0.01" required></label></div><div class="form-row"><label>مدة التوريد (يوم)<input name="delivery_days" type="number" min="0"></label><label>سريان العرض حتى<input name="valid_until" type="date"></label></div><label>الشروط<textarea name="terms" rows="2"></textarea></label><button class="primary" type="submit">حفظ عرض المورد</button></form></section>`:''}
  <section class="panel"><div class="panel-head"><div><h3>عروض الموردين والمقارنة</h3><p>درجات فنية وتجارية وسرعة توريد مع بوابة امتثال إلزامية قبل الترسية</p></div></div>${table(['رقم العرض','RFQ','المورد','القيمة','مدة التوريد','درجات التقييم (فني/تجاري/توريد)','الحالة'],quoteRows)}</section>
  ${canOrder?`<section class="panel"><div class="panel-head"><div><h3>تقييم وترسية عرض</h3><p>يسجل التقييم وأسبابه في قاعدة البيانات ويغلق المنافسة عند الترسية</p></div></div><form id="scm-evaluation-form" class="data-form"><div class="form-row"><label>العرض المراد تقييمه<select name="quote_id" required>${quotes.filter(q=>['received','under_review'].includes(q.status)).map(q=>`<option value="${esc(q.id)}">${esc(q.quote_no||q.id.slice(0,8))} · ${esc(supplierName(q.supplier_id))} · ${fmtMoney(q.total_amount)}</option>`).join('')}</select></label><label>اجتياز الامتثال<select name="compliance_pass" required><option value="false">لم يجتز</option><option value="true">اجتاز</option></select></label></div><div class="form-row"><label>التقييم الفني (0–100)<input name="technical_score" type="number" min="0" max="100" required></label><label>التقييم التجاري (0–100)<input name="commercial_score" type="number" min="0" max="100" required></label></div><div class="form-row"><label>تقييم التوريد (0–100)<input name="delivery_score" type="number" min="0" max="100" required></label><label>مبررات التقييم<textarea name="evaluation_note" required rows="2"></textarea></label></div><button class="primary" type="submit">حفظ التقييم وترسية العرض</button></form></section>`:''}
  ${canOrder && requests.some(r=>r.status==='approved') && suppliers.some(s=>s.approval_status==='approved')?`<section class="panel"><div class="panel-head"><div><h3>إصدار أمر شراء</h3><p>لا يتاح إلا لطلب معتمد ومورد معتمد وعرض تمت ترسيته</p></div></div><form id="scm-po-form" class="data-form"><div class="form-row"><label>رقم أمر الشراء<input name="order_no" required placeholder="PO-2026-001"></label><label>طلب شراء معتمد<select name="request_id" required>${requests.filter(r=>r.status==='approved').map(r=>`<option value="${esc(r.id)}">${esc(r.request_no)} · ${esc(r.title)}</option>`).join('')}</select></label></div><div class="form-row"><label>عرض مرسى<select name="quote_id" required>${quotes.filter(q=>q.status==='selected').map(q=>`<option value="${esc(q.id)}">${esc(q.quote_no||q.id.slice(0,8))} · ${esc(supplierName(q.supplier_id))}</option>`).join('')}</select></label><label>التسليم المتوقع<input name="expected_delivery_date" type="date"></label></div><button class="primary" type="submit">إنشاء أمر شراء مسودة</button></form></section>`:''}
  <section class="panel"><div class="panel-head"><div><h3>أوامر الشراء</h3><p>الاعتماد المالي يحجز المخصصات المرتبطة، والإصدار خطوة مستقلة</p></div></div>${table(['رقم الأمر','طلب الشراء','المورد','القيمة','التسليم المتوقع','الحالة','الإجراء'],orderRows)}</section>
  <section class="panel"><div class="panel-head"><div><h3>حجوزات الميزانية</h3><p>التزامات الأوامر المعتمدة المرتبطة ببنود ميزانية معتمدة</p></div></div>${table(['أمر الشراء','بند الميزانية','المبلغ المحجوز','الحالة'],commitments.map(c=>`<tr><td>${esc(orders.find(o=>o.id===c.purchase_order_id)?.order_no||'—')}</td><td>${esc(budgetLineLabel(budgetLines.find(l=>l.id===c.budget_line_id)||{}))}</td><td>${fmtMoney(c.committed_amount)}</td><td>${statusPill(c.status)}</td></tr>`))}</section>
  ${canReceive && orders.some(o=>['issued','partially_received'].includes(o.status))?`<section class="panel"><div class="panel-head"><div><h3>تسجيل استلام</h3><p>لا يسمح النظام بتجاوز الكمية المطلوبة أو الاستلام قبل إصدار الأمر</p></div></div><form id="scm-receipt-form" class="data-form"><div class="form-row"><label>رقم محضر الاستلام<input name="receipt_no" required placeholder="GR-2026-001"></label><label>أمر الشراء<select name="order_id" required>${orders.filter(o=>['issued','partially_received'].includes(o.status)).map(o=>`<option value="${esc(o.id)}">${esc(o.order_no)}</option>`).join('')}</select></label></div><div class="form-row"><label>المستودع<select name="warehouse_id"><option value="">غير مطلوب للخدمات</option>${warehouseOpts}</select></label><label>بند أمر الشراء<select name="order_line_id" required>${orderLines.filter(l=>orders.some(o=>o.id===l.order_id&&['issued','partially_received'].includes(o.status))&&Number(l.received_quantity)<Number(l.quantity)).map(l=>`<option value="${esc(l.id)}">${esc(orders.find(o=>o.id===l.order_id)?.order_no||'')} · ${esc(l.description)} · المتبقي ${fmtNumber(Number(l.quantity)-Number(l.received_quantity))}</option>`).join('')}</select></label><label>تاريخ الاستلام<input name="received_on" type="date"></label></div><div class="form-row"><label>الكمية المستلمة<input name="received_quantity" type="number" min="0.001" step="0.001" required></label><label>الكمية المقبولة<input name="accepted_quantity" type="number" min="0" step="0.001" required></label></div><label>ملاحظات<textarea name="notes" rows="2"></textarea></label><button class="primary" type="submit">تسجيل الاستلام</button></form></section>`:''}
  <section class="panel"><div class="panel-head"><div><h3>محاضر الاستلام</h3><p>سجل الكميات المستلمة والمقبولة وربطها بأمر الشراء</p></div></div>${table(['رقم الاستلام','أمر الشراء','التاريخ','عدد البنود','الحالة'],receiptRows)}</section>
  <div class="stats-grid">${statCard('الأصناف',fmtNumber(items.length),'كتالوج الأصناف','▦')}${statCard('المستودعات',fmtNumber(warehouses.length),'مواقع التخزين','⌂')}${statCard('أرصدة المخزون',fmtNumber(balances.length),'أرصدة صنف/مستودع','▤')}${statCard('حركات المخزون',fmtNumber(movements.length),'دفتر حركات الاستلام','↔')}</div>
  ${canInventory && warehouses.some(w=>w.is_active) && stockItemOpts?`<section class="panel"><div class="panel-head"><div><h3>عمليات المخزون: صرف وتحويل وجرد</h3><p>كل عملية تُحفظ كمسودة ثم ترسل لمسار الموافقة؛ لا يتغير الرصيد إلا بعد اعتمادها</p></div><span class="subtle-tag">موافقة قبل الترحيل</span></div><form id="scm-inventory-operation-form" class="data-form"><div class="form-row"><label>رقم العملية<input name="operation_no" required placeholder="INV-2026-001"></label><label>نوع العملية<select name="operation_type" required><option value="issue">صرف مخزني</option><option value="transfer">تحويل بين مستودعين</option><option value="stocktake">تسوية جرد</option></select></label></div><label>وصف العملية<input name="title" required placeholder="سبب الصرف أو التحويل أو الجرد"></label><div class="form-row"><label>الصنف المخزني<select name="item_id" required>${stockItemOpts}</select></label><label>المستودع المصدر / محل الجرد<select name="source_warehouse_id" required>${warehouseOpts}</select></label></div><div class="form-row"><label>الكمية المطلوب صرفها / تحويلها<input name="quantity" type="number" min="0.001" step="0.001" value="1" required></label><label>المستودع المستلم (للتحويل فقط)<select name="destination_warehouse_id"><option value="">غير محدد</option>${warehouseOpts}</select></label></div><div class="form-row"><label>الكمية الفعلية بعد الجرد (للجرد فقط)<input name="counted_quantity" type="number" min="0" step="0.001"></label><label>المشروع<select name="project_id"><option value="">بدون مشروع</option>${projectOpts}</select></label></div><div class="form-row"><label>مركز التكلفة<select name="cost_center_id"><option value="">غير محدد</option>${costOpts}</select></label><label>ملاحظات<textarea name="notes" rows="2"></textarea></label></div><button class="primary" type="submit">حفظ العملية وإرسالها للموافقة</button></form></section>`:''}
  <section class="panel"><div class="panel-head"><div><h3>سجل عمليات المخزون</h3><p>عمليات الصرف والتحويل والجرد وحالات اعتمادها وترحيلها</p></div></div>${table(['رقم العملية','الوصف','النوع','عدد البنود','التاريخ','الحالة'],operationRows)}</section>
  <section class="panel"><div class="panel-head"><div><h3>أرصدة المخزون</h3><p>الأرصدة تتغير من الاستلامات المقبولة وعمليات الصرف والتحويل والجرد المعتمدة</p></div></div>${table(['المستودع','رمز الصنف','الصنف','الرصيد','حد إعادة الطلب','التنبيه'],balances.map(b=>{const it=items.find(i=>i.id===b.item_id),wh=warehouses.find(w=>w.id===b.warehouse_id);const low=Number(b.quantity_on_hand)<=Number(it?.minimum_stock||0);return `<tr><td>${esc(wh?.name_ar||'—')}</td><td>${esc(it?.sku||'—')}</td><td>${esc(it?.name_ar||'—')}</td><td>${fmtNumber(b.quantity_on_hand)}</td><td>${fmtNumber(it?.minimum_stock||0)}</td><td>${low?statusPill('low'):'—'}</td></tr>`;}))}</section>`;

  const inventoryOperationForm=host.querySelector('#scm-inventory-operation-form');
  if(inventoryOperationForm) inventoryOperationForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(inventoryOperationForm);const kind=fd.get('operation_type');const qty=Number(fd.get('quantity'));const counted=fd.get('counted_quantity')===''?null:Number(fd.get('counted_quantity'));if(!(qty>0)){toast('أدخل كمية صحيحة أكبر من صفر','error');return;}if(kind==='transfer'&&!fd.get('destination_warehouse_id')){toast('حدد المستودع المستلم للتحويل','error');return;}if(kind==='stocktake'&&(counted===null||counted<0)){toast('أدخل الكمية الفعلية للجرد','error');return;}if(kind!=='transfer'&&fd.get('destination_warehouse_id')){toast('المستودع المستلم يستخدم للتحويل فقط','error');return;}const {data:opId,error:opError}=await supabase.schema('scm').rpc('create_inventory_operation',{p_operation_no:fd.get('operation_no'),p_operation_type:kind,p_title:fd.get('title'),p_notes:fd.get('notes')||null,p_project_id:fd.get('project_id')||null,p_cost_center_id:fd.get('cost_center_id')||null});if(opError){toast(cleanError(opError),'error');return;}const {error:lineError}=await supabase.schema('scm').rpc('add_inventory_operation_line',{p_operation_id:opId,p_line_no:1,p_item_id:fd.get('item_id'),p_source_warehouse_id:fd.get('source_warehouse_id'),p_quantity:qty,p_destination_warehouse_id:fd.get('destination_warehouse_id')||null,p_counted_quantity:kind==='stocktake'?counted:null,p_notes:fd.get('notes')||null});if(lineError){toast(`حُفظت مسودة العملية لكن تعذرت إضافة البند: ${cleanError(lineError)}. راجع سجل العمليات قبل إعادة الإنشاء.`,'error');await loadPage('scm');return;}const {error:submitError}=await supabase.schema('scm').rpc('submit_inventory_operation',{p_operation_id:opId});if(submitError){toast(`حُفظت العملية كمسودة ولم ترسل للموافقة: ${cleanError(submitError)}`,'error');await loadPage('scm');return;}toast('أُرسلت عملية المخزون للموافقة. سيُحدّث الرصيد بعد الاعتماد فقط.','success');await loadPage('scm');};

  const warehouseForm=host.querySelector('#scm-warehouse-form');
  if(warehouseForm) warehouseForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(warehouseForm);const {error}=await supabase.schema('scm').rpc('create_warehouse',{p_code:fd.get('warehouse_code'),p_name:fd.get('name_ar'),p_location:fd.get('location_text')||''});if(error){toast(cleanError(error),'error');return;}toast('تم حفظ المستودع.','success');await loadPage('scm');};
  const itemForm=host.querySelector('#scm-item-form');
  if(itemForm) itemForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(itemForm);const {error}=await supabase.schema('scm').rpc('create_inventory_item',{p_sku:fd.get('sku'),p_name_ar:fd.get('name_ar'),p_item_type:fd.get('item_type'),p_unit:fd.get('unit'),p_minimum_stock:Number(fd.get('minimum_stock')||0)});if(error){toast(cleanError(error),'error');return;}toast('تم حفظ الصنف.','success');await loadPage('scm');};
  const supplierForm=host.querySelector('#scm-supplier-form');
  if(supplierForm) supplierForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(supplierForm);const payload=Object.fromEntries(fd.entries());payload.tenant_id=state.tenant.id;payload.created_by=state.user.id;payload.payment_terms_days=payload.payment_terms_days?Number(payload.payment_terms_days):null;payload.approval_status='pending';for(const k of Object.keys(payload))if(payload[k]==='')payload[k]=null;const {error}=await supabase.schema('scm').from('suppliers').insert(payload);if(error){toast(cleanError(error),'error');return;}toast('تم حفظ ملف المورد بانتظار المراجعة.','success');await loadPage('scm');};
  const prForm=host.querySelector('#scm-pr-form');
  if(prForm) prForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(prForm);const qty=Number(fd.get('quantity')),price=Number(fd.get('estimated_unit_price'));if(!(qty>0)||price<0){toast('تحقق من الكمية والسعر','error');return;}const {data,error}=await supabase.schema('scm').rpc('create_purchase_request',{p_request_no:fd.get('request_no'),p_title:fd.get('title'),p_description:fd.get('description')||null,p_project_id:fd.get('project_id')||null,p_org_unit_id:fd.get('org_unit_id')||null,p_cost_center_id:fd.get('cost_center_id')||null,p_needed_by:fd.get('needed_by')||null,p_priority:fd.get('priority'),p_line_description:fd.get('line_description'),p_quantity:qty,p_unit:fd.get('unit'),p_estimated_unit_price:price,p_budget_line_id:fd.get('budget_line_id')||null,p_item_id:fd.get('item_id')||null});if(error){toast(cleanError(error),'error');return;}toast('تم إنشاء طلب الشراء وبنده في عملية واحدة كمسودة.','success');await loadPage('scm');};
  const rfqForm=host.querySelector('#scm-rfq-form');
  if(rfqForm) rfqForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(rfqForm);const req=fd.get('request_id');const rfqPayload={tenant_id:state.tenant.id,rfq_no:fd.get('rfq_no'),request_id:req,title:fd.get('title'),closing_date:fd.get('closing_date')||null,status:'draft',created_by:state.user.id};const {data,error}=await supabase.schema('scm').from('rfqs').insert(rfqPayload).select('id').single();if(error){toast(cleanError(error),'error');return;}const chosen=[...rfqForm.querySelector('[name="supplier_ids"]').selectedOptions].map(o=>o.value);if(chosen.length){const rows=chosen.map(supplier_id=>({tenant_id:state.tenant.id,rfq_id:data.id,supplier_id}));const inv=await supabase.schema('scm').from('rfq_suppliers').insert(rows);if(inv.error){toast(`أنشئ طلب العروض لكن تعذرت بعض الدعوات: ${cleanError(inv.error)}`,'error');return;}}toast('تم إنشاء مسودة طلب العروض والدعوات. يلزم إصدارها وفق الإجراء المعتمد.','success');await loadPage('scm');};
  host.querySelectorAll('[data-submit-supplier]').forEach(btn=>btn.onclick=async()=>{if(!confirm('إرسال ملف المورد لمسار الاعتماد؟'))return;btn.disabled=true;const {data,error}=await supabase.schema('scm').rpc('submit_supplier_for_approval',{p_supplier_id:btn.dataset.submitSupplier});if(error){toast(cleanError(error),'error');btn.disabled=false;return;}toast('أُرسل المورد إلى قائمة الموافقات.','success');await loadPage('scm');});
  host.querySelectorAll('[data-submit-pr]').forEach(btn=>btn.onclick=async()=>{if(!confirm('إرسال طلب الشراء للموافقة المؤسسية؟'))return;btn.disabled=true;const {data,error}=await supabase.schema('scm').rpc('submit_purchase_request',{p_request_id:btn.dataset.submitPr});if(error){toast(cleanError(error),'error');btn.disabled=false;return;}toast('أُرسل طلب الشراء إلى مسار الموافقات.','success');await loadPage('scm');});
  host.querySelectorAll('[data-issue-rfq]').forEach(btn=>btn.onclick=async()=>{if(!confirm('إصدار طلب عروض الأسعار للموردين المدعوين؟'))return;btn.disabled=true;const {error}=await supabase.schema('scm').rpc('issue_rfq',{p_rfq_id:btn.dataset.issueRfq});if(error){toast(cleanError(error),'error');btn.disabled=false;return;}toast('تم إصدار طلب العروض.','success');await loadPage('scm');});
  const quoteForm=host.querySelector('#scm-quote-form');
  if(quoteForm) quoteForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(quoteForm);const q={tenant_id:state.tenant.id,rfq_id:fd.get('rfq_id'),supplier_id:fd.get('supplier_id'),quote_no:fd.get('quote_no')||null,total_amount:Number(fd.get('total_amount')),delivery_days:fd.get('delivery_days')?Number(fd.get('delivery_days')):null,valid_until:fd.get('valid_until')||null,terms:fd.get('terms')||null,status:'under_review',created_by:state.user.id};const {error}=await supabase.schema('scm').from('supplier_quotes').insert(q);if(error){toast(cleanError(error),'error');return;}toast('تم تسجيل العرض بحالة قيد المراجعة.','success');await loadPage('scm');};
  const evaluationForm=host.querySelector('#scm-evaluation-form');
  if(evaluationForm) evaluationForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(evaluationForm);if(fd.get('compliance_pass')!=='true'){toast('لا يمكن ترسية العرض قبل اجتياز الامتثال.','error');return;}const {error}=await supabase.schema('scm').rpc('award_supplier_quote',{p_quote_id:fd.get('quote_id'),p_technical_score:Number(fd.get('technical_score')),p_commercial_score:Number(fd.get('commercial_score')),p_delivery_score:Number(fd.get('delivery_score')),p_compliance_pass:true,p_evaluation_note:fd.get('evaluation_note')});if(error){toast(cleanError(error),'error');return;}toast('تم حفظ التقييم وترسية العرض وإغلاق المنافسة.','success');await loadPage('scm');};
  host.querySelectorAll('[data-submit-po]').forEach(btn=>btn.onclick=async()=>{if(!confirm('إرسال أمر الشراء لمسار الاعتماد؟ قد يؤدي الاعتماد إلى حجز بنود الميزانية المرتبطة.'))return;btn.disabled=true;const {error}=await supabase.schema('scm').rpc('submit_purchase_order',{p_order_id:btn.dataset.submitPo});if(error){toast(cleanError(error),'error');btn.disabled=false;return;}toast('أُرسل أمر الشراء للموافقة.','success');await loadPage('scm');});
  host.querySelectorAll('[data-issue-po]').forEach(btn=>btn.onclick=async()=>{if(!confirm('إصدار أمر الشراء للمورد؟'))return;btn.disabled=true;const {error}=await supabase.schema('scm').rpc('issue_purchase_order',{p_order_id:btn.dataset.issuePo});if(error){toast(cleanError(error),'error');btn.disabled=false;return;}toast('تم إصدار الأمر في النظام. إرسال البريد للمورد غير مفعل في هذا الإصدار.','success');await loadPage('scm');});
  const receiptForm=host.querySelector('#scm-receipt-form');
  if(receiptForm) receiptForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(receiptForm);const {error}=await supabase.schema('scm').rpc('create_goods_receipt',{p_receipt_no:fd.get('receipt_no'),p_order_id:fd.get('order_id'),p_received_on:fd.get('received_on')||null,p_order_line_id:fd.get('order_line_id'),p_received_quantity:Number(fd.get('received_quantity')),p_accepted_quantity:Number(fd.get('accepted_quantity')),p_notes:fd.get('notes')||null,p_warehouse_id:fd.get('warehouse_id')||null});if(error){toast(cleanError(error),'error');return;}toast('تم تسجيل الاستلام وتحديث الكمية المستلمة على أمر الشراء.','success');await loadPage('scm');};
  const poForm=host.querySelector('#scm-po-form');
  if(poForm) poForm.onsubmit=async e=>{e.preventDefault();const fd=new FormData(poForm);const quote=quotes.find(q=>q.id===fd.get('quote_id'));if(!quote||quote.status!=='selected'){toast('اختر عرضاً مرسى صالحاً','error');return;}const request=requests.find(r=>r.id===fd.get('request_id'));if(!request||request.status!=='approved'){toast('طلب الشراء غير معتمد.','error');return;}if(!rfqs.some(f=>f.id===quote.rfq_id&&f.request_id===request.id)){toast('العرض لا يعود لطلب الشراء المختار.','error');return;}const payload={tenant_id:state.tenant.id,order_no:fd.get('order_no'),request_id:request.id,supplier_id:quote.supplier_id,quote_id:quote.id,expected_delivery_date:fd.get('expected_delivery_date')||null,total_amount:0,created_by:state.user.id,status:'draft'};const {data:created,error}=await supabase.schema('scm').from('purchase_orders').insert(payload).select('id').single();if(error){toast(cleanError(error),'error');return;}const lines=requestLines.filter(l=>l.request_id===request.id);if(!lines.length){toast('طلب الشراء لا يحتوي بنوداً.','error');return;}for(let i=0;i<lines.length;i++){const linePrice=lines.length===1?Number(quote.total_amount)/Number(lines[i].quantity):Number(lines[i].estimated_unit_price||0);const {error:lineError}=await supabase.schema('scm').rpc('create_purchase_order_line',{p_order_id:created.id,p_request_line_id:lines[i].id,p_line_no:i+1,p_unit_price:linePrice});if(lineError){toast(`تم إنشاء مسودة الأمر لكن تعذرت إضافة أحد البنود: ${cleanError(lineError)}. راجع المسودة قبل المتابعة.`,'error');return;}}toast('تم إنشاء مسودة أمر الشراء وبنوده. لم يتم إصدارها للمورد.','success');await loadPage('scm');};
}

async function renderExpansion(host) {
  const modules = [
    ['المشاريع ومكتب إدارة المشاريع','مهيأ أساسياً','تم إنشاء المشاريع والمهام والمراحل الرئيسية وسياسات RLS؛ واجهة التشغيل الأولية متاحة.'],
    ['المشتريات وسلسلة الإمداد','مهيأ أساسياً','الموردون وطلبات الشراء وطلبات العروض والتقييم والترسية وأوامر الشراء والاستلام وربط الموافقات وحجوزات الميزانية.'],
    ['ملفات الموردين واعتمادهم','مهيأ أساسياً','ملفات الموردين ومسار الاعتماد والربط بدورة الشراء؛ إدارة العقود والمرفقات مرحلة توسع لاحقة.'],
    ['المخزون والمستودعات','قيد البناء','الاستلام مربوط بأمر الشراء؛ سجل الأصناف والمستودعات والأرصدة وحركات المخزون لم يُفعّل بعد.'],
    ['المبيعات والعملاء والفوترة','غير مهيأ','يلزم CRM وعروض أسعار وأوامر وفواتير وضوابط ضريبية.'],
    ['الموارد البشرية والرواتب','جزئي','المتاح حالياً سجل الوظائف المخططة فقط؛ لا يوجد ملف موظف أو مسير رواتب.'],
    ['الذكاء التشغيلي','قيد التخطيط','سيُبنى فوق بيانات فعلية ومؤشرات موثوقة مع إبقاء القرارات الحساسة بموافقة بشرية.'],
    ['إدارة الوثائق والمراسلات','غير مهيأ','يلزم تخزين خاص بسياسات وصول واحتفاظ وسجل تنزيل.']
  ];
  host.innerHTML = `<div class="section-intro"><h1>مركز التوسع التشغيلي</h1><p>خارطة الوحدات المطلوبة للمنظومة الكاملة، مع تمييز ما هو موجود فعلاً عما يحتاج إلى تصميم قاعدة بيانات وتنفيذ مستقل.</p></div><section class="panel"><div class="table-wrap"><table><thead><tr><th>الوحدة</th><th>الحالة</th><th>متطلبات المرحلة</th></tr></thead><tbody>${modules.map(m=>`<tr><td>${esc(m[0])}</td><td>${statusPill(m[1]==='جزئي'?'in_progress':'planned')}</td><td>${esc(m[2])}</td></tr>`).join('')}</tbody></table></div></section><div class="notice">لا يتم عرض بيانات تجريبية على أنها سجلات فعلية. كل وحدة ستتحول إلى شاشة تشغيل بعد إنشاء مخططها، وسياسات RLS، ومسارات الموافقات، واختبارات التكامل.</div>`;
}

if (!configured) setupScreen();
else {
  supabase.auth.onAuthStateChange((_event, session) => { if (!session) { state.user=null; if (app.querySelector('.shell')) loginScreen(); } });
  bootstrap();
}
